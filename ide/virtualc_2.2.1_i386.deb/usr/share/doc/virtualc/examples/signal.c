/* signal.c: Example for the Virtual-C IDE by D. Pawelczak */
/* Note, needs the C11 flag set! */

#define PRINT(...)  { fprintf(stderr, __VA_ARGS__); \
	printf(__VA_ARGS__); }

#include <stdio.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define BUFFER_SIZE 80

void SignalHandler(int sig)
{
	switch(sig)
	{
		case SIGINT:
			PRINT("CTRL+C was pressed ... IGNORED!\n" \
		           "YOU MUST ENTER \'EXIT\' to leave...\n");
			signal(SIGINT, SignalHandler); /* reestablish handler */
			break;
		case SIGABRT:
			PRINT("You closed the console window or called abort()...IGNORED!\n" \
		           "Re-open the console and enter \'EXIT\' to leave...\n");
			signal(SIGABRT, SignalHandler); /* reestablish handler */
			break;
		case SIGSEGV:
			PRINT("Received signal: Segmentation fault ... IGNORED!\n" \
		           "This was just a test ... Should not happen again!\n");
			break;
		case SIGFPE:
			PRINT("Received signal: Floating point exception ... IGNORED!\n" \
		           "I didn't code this ... \n");
			break;
		case SIGILL:
			PRINT("Received signal: Invalid instruction ... IGNORED!\n" \
		           "Although, I don't know how to resume ... I better call abort() \'EXIT\' \n");
			abort();	
			break;
		default:
			PRINT("Shouldn't come around here ...\n");
			break;
	}
}

int main(void)
{
	char* foo= NULL;
	char buffer[BUFFER_SIZE] = "";
	signal(SIGABRT, SignalHandler); /* install handlers */
	signal(SIGILL, SignalHandler);
	signal(SIGFPE, SignalHandler);
	signal(SIGSEGV, SignalHandler);
	signal(SIGINT, SignalHandler);
//	signal(SIGINT,SIG_IGN); // tests for ignore & default behaviour
//	signal(SIGINT,SIG_DFL);
	
	foo[0] = 0x1a; /* should trigger a segmentation fault */
	printf("Press CTRL+C, close the Console-Window or enter EXIT!\n");
	while (fgets(buffer, sizeof(buffer), stdin))
	{
		if (strstr(buffer, "EXIT"))
			break;
	}
	printf("Well done! Goodbye!\n");
	return 0;
}
