/* Taken from "Start in die C-Programmierung" (ISBN 978-3-8440-0832-6) by D. Pawelczak */
#include <stdio.h>
#include <string.h>


void StrcpyBlank(char *dest, char *src)
{
	if (!dest || !src)
		return;

	while (*src) 
	{
		*dest = '-';
		dest++;
		src++;
	}
	*dest = '\0';
}
void StrFillCmp(char* dest, char* src, char ch)
{
	if (!dest || !src)
		return;

	while (*src) 
	{
		if (*src == ch)
			*dest = ch;
		dest++;
		src++;
	}
}
	
#define MAX_WORD_LEN 64 
#define SCREEN_LINES 25

int main(void)
{
    char loesung[MAX_WORD_LEN] = { 0 };
	char suchWort[MAX_WORD_LEN] = { 0 };
	char ch = 0;
	int i = 0;
	int count = 0;

	printf("Player 1: Please enter your secret word here: ");
	scanf("%63s", suchWort);
	
	for (i = 0 ; i < SCREEN_LINES; i++)
		puts(""); /* clear screen ... */
	
	printf("Player 2:\n");
	StrcpyBlank(loesung, suchWort);
	while (strcmp(suchWort, loesung) != 0)
	{
		printf("Your current guess:    %s\n", loesung);
		printf("Guess the next letter: ");
		fflush(stdin);
		scanf("%c", &ch);
		StrFillCmp(loesung, suchWort, ch);
		++count;
	}
	
	printf("Hurray!\nYou've got it with just %d tries: %s\n", count, suchWort);
	
	return 0;
}
