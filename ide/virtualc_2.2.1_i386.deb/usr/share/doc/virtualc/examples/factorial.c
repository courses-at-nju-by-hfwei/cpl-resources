/* simple Virtual-C example to calculate the factorial of n      */
/* the factorial of n is the product: n * factorial(n - 1)       */

/* you might step-through it with F11, activating the procedure
   visualization (menu Debug / Plugins / ProcedureVisualization) */
#include <stdio.h>

int factorial(int n) {
	if (n <= 1)
		return n;
	return n * factorial(n - 1);
}

int main(void){
	int n = 3;
	int result = 0;
	
	printf("The factorial of %d is: ", n);
	result = factorial(n);
	printf("%d\n", result);
	
	return 0;
}
