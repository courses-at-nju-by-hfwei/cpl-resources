/* SimpleC Compiler example for compound literals (c) by D. Pawelczak */
/* Note, this example requires the /C11 option!                       */

#include <stdio.h>
#include <time.h>

#define NAME_LEN 20
#define START_YEAR 1900

typedef struct tDay{
	int day;
	int month;
	int year;
} tDay;

typedef struct {
	struct tDay date;
	char name[NAME_LEN];
} tBirthDay;

int printBirthDay(const tBirthDay *m) {
	return printf("%s's birthday is on %04d-%02d-%02d\n",
		m->name, m->date.year, m->date.month, m->date.day );
}
int checkAndPrintBirthDays(const tBirthDay *all[]) {
	struct tm *t;
	int isBirthDay = 0;
	time_t current = time(NULL);

	t = localtime(&current);
	while (all && *all)	{
		const tBirthDay *m = *all;
		if (t->tm_mday == m->date.day && t->tm_mon + 1 == m->date.month) {
			isBirthDay = 1;
			printf("Today is %s's birthday! " \
					  "%s is %d years old!\n", \
					  m->name, m->name, t->tm_year + START_YEAR - m->date.year);
		}
		all++;
	}
	return isBirthDay; 
}

int main(void) {
	/* a standard C90 initialization */
	const tBirthDay s = { 17, 7, 2007, "Steffi" };
	/* struct initialization with designator */
	tDay d = { .day = 17, .month = 7, .year = 2014};
	/* flip order in struct initialization */
	tBirthDay a = { .name = "Hanna" , .date = d };
	/* partly initialization */
	tBirthDay n = {.name[0] = 'M', .name[1]='i', .name[2]='k', .name[3]='e' };
	tBirthDay *m = NULL;
	d.year -=6;
	/* initializing a pointer with a compound literal */
	m = &(tBirthDay) { d, "Matti" };
	/* function call with a compound literal */
	printBirthDay(&(tBirthDay){ 14, 4, .date.year = 2014, "Birgit" });
	printBirthDay(&a);
	printBirthDay(m);
	/* an unordered compound literal */
	n.date = (tDay){ .day = 2, .year = 2004, .month = 3 };
	printBirthDay(&n);
	printBirthDay(&s);
	puts("Let's see, if someone's birthday is today...");
	/* an array containing pointers to structs */
	const tBirthDay * all[] = { &(const tBirthDay){ 14, 4, .date.year = 2014, "Birgit" },
						 (const tBirthDay*) &a,
						 [2] = (const tBirthDay*) m,
						 (const tBirthDay*) &n,
                        &s,
				  		 NULL };
	

	if (!checkAndPrintBirthDays(all))
		puts("No. See you!");
	
	return 0;
}
	 
