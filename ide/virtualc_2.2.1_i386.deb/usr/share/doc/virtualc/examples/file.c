#include <stdio.h>

int main(int argc, char *argv[]) { 
 
	FILE* f = fopen("file.c", "r");
	
	if (f)
	{
		while (!feof(f))
			putchar(fgetc(f));
		fclose(f);
	}
	return 0;
}