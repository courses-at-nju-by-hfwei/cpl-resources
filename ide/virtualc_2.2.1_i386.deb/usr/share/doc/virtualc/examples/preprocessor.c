#include <stdio.h>
#define MAXIMUM 100
#define MINIMUM 5

int main(void){
	int b = MINIMUM;
	int c = 5 * MINIMUM;
	int a = b + c;
	if( a == MAXIMUM)
		printf("a hat Max erreicht");
	return 0;
}