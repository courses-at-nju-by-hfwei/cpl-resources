//
//  checkHello1.c
//  VirtualC
//
//  Created by Dieter Pawelczak on 05.03.14.
//
//  A functional test for a simple scanf-exercise:
//  it evaluates the parameters of the functions scanf, scanf_s or fgets
//  and evaluates the behaviour, when reading in a string.
//  First it checks a valid string, then it tries a buffer overrun


/* include the exercise extensions for the MOP virtual machine */
#include <mopvmex.h>
#include <string.h>
#include <stdarg.h>


/* the user function, that is tested */
extern int main(void);


/* counter for calls to scanf or fgets */
static int scanfCalled = 0;

/* a replacal for scanf() */
static int checkint(char*format,...) {
    va_list argptr;
	va_start(argptr,format);
    /* test on first call */
    if (!scanfCalled)
    {
        if (!strstr(format,"%31s") && !strstr(format,"%.31s"))
        {
            _printWarningToOutput("You should limit the input size using %31s to read no more than 31 characters.");
            if (!strstr(format,"%32s") && !strstr(format,"%.32s") &&
                !strstr(format,"%s")) {
                _printWarningToOutput("You should read c-strings with the format specifier %s.");
            }
        }
    }
    ++scanfCalled;
	return vfscanf(stdin,format,argptr);
}

/* a replacal for scanf_s() */
static int checkint_s(char*format,...) {
    va_list argptr;
	va_start(argptr,format);
    /* test on first call */
    if (!scanfCalled)
    {
        if (!strstr(format,"%31s") && !strstr(format,"%.31s"))
        {
            _printWarningToOutput("You should limit the input size using %31s to read no more than 31 characters.");
            if (!strstr(format,"%32s") && !strstr(format,"%.32s") &&
                !strstr(format,"%s")) {
                _printWarningToOutput("You should read c-strings with the format specifier %s.");
            }
        }
    }
    ++scanfCalled;
	return vfscanf_s(stdin,format,argptr);
}
/* a replacal for fgets() */
static int checkint2(char*buffer, size_t size, FILE* in) {
    if (in != stdin)
        _printWarningToOutput("fgets() should read from stdin.");
    if (size != 32 && size != 4096)
        _printWarningToOutput("You should pass the correct buffer size to fgets(). The variable should have 32 bytes to store the name.");
    if (!scanfCalled)
    {
        if (_editorContains("\\bfgets\\b") && !_editorContains("fgets\\s*\\(\\s*[a-zA-Z_0-9]+\\s*,\\s*sizeof"))
            _printWarningToOutput("You should use <code>sizeof</code> to pass the buffer size to fgets().");
   }

    ++scanfCalled;
    int len = fread( buffer, 1, size-1, in);
    if (len>0)
    {
        buffer[len] = 0;
        char*tmp = strchr(buffer,'\n');
        if (tmp)
            *(tmp+1)=0; // terminate after \n
        return buffer;
    }
    
	return NULL;
}
/************************************************************************/
/* start of functional test */
int _mopcheck(void)
{
    int nameIsUsed = 0;
    int hasError = 0;
    char dustbin[256];
    _initMopCheck();
    /* simulate a user input "Cecile" and ENTER */
    _redirectStdin("Debbie\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",15);
    /* redirect the stdout - in case anything is already printed */
    _redirectStdout(dustbin, sizeof(dustbin));

    /* redirect the function calls in the test program to our test functions */
	_relinkSymbol(scanf,checkint);
	_relinkSymbol(fgets,checkint2);
	_relinkSymbol(scanf_s,checkint_s);
    /* limit the number of machine instructions for the test and enable the exception handler */
 	_setExecutionLimit(200000);
    
    /* call the test program */
    char *s;
    char buffer[1024] = "<code>";
    if (main() != 0) {
        /* now check the contents of 'name' */
        s = _getInvalidVariableValue(buffer+6, sizeof(buffer)-6, 1, "name");
        _printWarningToOutput("main() should return EXIT_SUCCESS.");
    } else
        s = _getInvalidVariableValue(buffer+6, sizeof(buffer)-6, 1, "name");

    /* check if the number of machine instuction exceed the limit or an exception occured */
    if (_printFault("Your main does not return in expected time - test aborted.",
                    "An exception occurred - test aborted.")) {
		return 10;
	}
    
    if (!scanfCalled) {
        _printErrorToOutput("you should either call scanf() or fgets().");
        return 20;
    }
    
    
    /* check, if the variable name contains the simulated input */
    if (strstr(buffer,"Debbie")) {
        nameIsUsed = 1;
        if (strstr(buffer,"\\n")) {
            _printWarningToOutput("You should remove the line feed character from the input. Or simply use scanf().");
        }
        
    } else
    {
        if (strstr(s,"*undef"))
            
            _printWarningToOutput("Your variable is not called 'name'.");
        else {
            _printErrorToOutput("Your variable does not receive the correct data from the input. Please check, if you use scanf() or fgets() properly.");
            return 30;
            
        }
    }
   
    
    /* we check, if we do a buffer overrun */
    fflush(stdin);
#define A_LARGE_INPUT "Debbie7890123456789012345678901x__32_characters_and_more..."
    _redirectStdin(A_LARGE_INPUT "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",45);
  	_setExecutionLimit(200000);
    main();
    s = _getInvalidVariableValue(buffer+6, sizeof(buffer)-6, 1, "name");
    if (_printFault("Your main does not return in expected time for an input larger than 32 characters - test aborted.",
                    "An exception occurred, in case the input is longer than 32 characters - test aborted.")) {
		return 10;
	}
    
    if (nameIsUsed && !strstr(buffer,"Debbie"))
    {
        hasError = 1;
        _printErrorToOutput("An input with more than 32 characters does not return the first 31 characters. Please limit your input to read a maximum of 32 characters including the terminating nul-character.");
    }
    if (strstr(buffer,"Debbie")) {
        if (strstr(buffer,"1x")) {
            _printErrorToOutput("An input with more than 32 characters results in a missing nul-character in name. Please limit your input to read a maximum of 32 characters including the terminating nul-character.");
            hasError = 1;
        }
        
    }
    /* print more information on the error */
    if (hasError) {
        _printStringToOutput("The test input was: <code>" A_LARGE_INPUT);
        _printStringToOutput("</code>Your program read:");
        /* remove quotation marks */
        char *tmp = strrchr(s,'\"');
        if (tmp)
            *tmp = 0;
        *s=' ';
        _printStringToOutput(buffer);
        _printStringToOutput("</code>The first 'x' should be the terminating '\\0' character.");
        return 75;
        
    }
    if (!nameIsUsed) {
        _printWarningToOutput("You should call your local variable 'name' so that I can further check that your program reads the input properly.");
        
    }
    /* return the result 100% excellent, below 80% erroneous */
    return 100-_getWarnCount()*3; /* note, warnCount is increased with every call to _printWarningToOutput() */
}
