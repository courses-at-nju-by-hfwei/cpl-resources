//
//  checkHello1.c
//  VirtualC
//
//  Created by Dieter Pawelczak on 05.03.14.
//
//



#include <mopvmex.h>
#include <string.h>
#include <stdarg.h>


extern int main(void);



static int scanfCalled = 0;

/* a replacal for scanf() */
static int checkint(char*format,...) {
    va_list argptr;
	va_start(argptr,format);
    /* test on first call */
    if (!scanfCalled)
    {
        if (!strstr(format,"%31s") && !strstr(format,"%.31s"))
        {
            _printWarningToOutput("You should limit the input size using %31s to read no more than 31 characters.");
            if (!strstr(format,"%32s") && !strstr(format,"%.32s") &&
                !strstr(format,"%s")) {
                _printWarningToOutput("You should read c-strings with the format specifier %s.");
            }
        }
    }
    ++scanfCalled;
	return vfscanf(stdin,format,argptr);
}

/* a replacal for scanf_s() */
static int checkint_s(char*format,...) {
    va_list argptr;
	va_start(argptr,format);
    /* test on first call */
    if (!scanfCalled)
    {
        if (!strstr(format,"%31s") && !strstr(format,"%.31s"))
        {
            _printWarningToOutput("You should limit the input size using %31s to read no more than 31 characters.");
            if (!strstr(format,"%32s") && !strstr(format,"%.32s") &&
                !strstr(format,"%s")) {
                _printWarningToOutput("You should read c-strings with the format specifier %s.");
            }
        }
    }
    ++scanfCalled;
	return vfscanf_s(stdin,format,argptr);
}

/* a replacal for fgets() */
static int checkint2(char*buffer, size_t size, FILE* in) {
    if (in != stdin)
        _printWarningToOutput("fgets() should read from stdin.");
    if (size != 32 && size != 4096)
        _printWarningToOutput("You should pass the correct buffer size to fgets(). The variable should have 32 bytes to store the name.");
    if (!scanfCalled)
    {
     
        if (_editorContains("\\bfgets\\b") && !_editorContains("fgets\\s*\\(\\s*[a-zA-Z_0-9]+\\s*,\\s*sizeof"))
            _printWarningToOutput("You should use <code>sizeof</code> to pass the buffer size to fgets().");
    }
    
    ++scanfCalled;
    int len = fread( buffer, 1, size-1, in);
    if (len>0)
    {
        buffer[len] = 0;
        char*tmp = strchr(buffer,'\n');
        if (tmp)
            *(tmp+1)=0; // terminate after \n
        return buffer;
    }
    
	return NULL;
}
/* a replacal for printf() */
static int checkout(char*format,...) {
    char buffer[1024];
    int ret;
    va_list argptr;
	va_start(argptr,format);
    
    if (strstr(format,"Debbie"))
    {
         _printWarningToOutput("You should use a format specifier to print the name and not print the name directly.");
    }
    ret = vsnprintf(buffer,sizeof(buffer),format,argptr);
    fputs(buffer,stdout);
    return ret;
}


int _mopcheck(void)
{
    int nameIsUsed = 0;
    int hasError = 0;
    char valbuffer[1024] = "<code>";
    char buffer[1024] = "<code>";
    _initMopCheck();
    
    _redirectStdin("Debbie\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",15);
    _redirectStdout(buffer, sizeof(buffer));
    
	_relinkSymbol(scanf,checkint);
	_relinkSymbol(fgets,checkint2);
	_relinkSymbol(scanf_s,checkint_s);
    _relinkSymbol(printf,checkout);

 	_setExecutionLimit(200000);
    char *s;
    if (main() != 0){
        s = _getInvalidVariableValue(valbuffer+6, sizeof(valbuffer)-6, 1, "name");
        _printWarningToOutput("main() should return EXIT_SUCCESS.");

    } else
        s = _getInvalidVariableValue(valbuffer+6, sizeof(valbuffer)-6, 1, "name");

    if (_printFault("Your main does not return in expected time - test aborted.",
                    "An exception occurred - test aborted.")) {
		return 10;
	}
    
    if (!scanfCalled) {
        _printErrorToOutput("you should either call scanf() or fgets().");
        return 20;
    }
    
    /* now check the contents of the output */
    if (!_containsRegEx(buffer, "Debbie"))
    {
        _printErrorToOutput("Your program does not print the name read from the console.");
        return 30;
    }
    if (!_containsRegEx(buffer, "\\bDebbie\\b"))
    {
    _printWarningToOutput("You should separate the name in the greeting.");
    }
    if (!s)
        _printWarningToOutput("Your variable is not called 'name'.");
    else
    if (strstr(valbuffer,"Debbie")) {
        nameIsUsed = 1;
        if (strstr(valbuffer,"\\n")) {
            _printWarningToOutput("You should remove the line feed character from the input. Or simply use scanf().");
        }
        
    } 
    
    
    /* we check, if we do a buffer overrun */
    fflush(stdin);
#define A_LARGE_INPUT "Debbie7890123456789012345678901x__32_characters_and_more..."
    _redirectStdin(A_LARGE_INPUT "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",45);
    _redirectStdout(buffer, sizeof(buffer));
  	_setExecutionLimit(200000);
    main();
    if (_printFault("Your main does not return in expected time for an input larger than 32 characters- test aborted.",
                    "An exception occurred, in case the input is longer than 32 characters - test aborted.")) {
		return 10;
	}
    
    if (strstr(buffer,"Debbie")) {
        if (strstr(buffer,"Debbie7890123456789012345678901x")) {
            _printErrorToOutput("An input with more than 32 characters results in a missing nul-character in name. Please limit your input to read a maximum of 32 characters including the terminating nul-character.");
            hasError = 1;
        }
    } else
    {
        _printErrorToOutput("The output does not contain the name, in case the input is longer than 32 characters.");
        hasError = 1;
    }
    if (hasError) {
        _printStringToOutput("The test input was: <code>" A_LARGE_INPUT);
        _printStringToOutput("</code>Your program prints:");
        _printStringToOutput(buffer);
        _printStringToOutput("</code>The first 'x' in the name should be the terminating '\\0' character.");
        return 75;
        
    }
    _redirectStdin("Dieter\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",45);
    fflush(stdin);
    *buffer = 0;
    _redirectStdout(buffer, sizeof(buffer));
  	_setExecutionLimit(200000);
    main();
    if (strstr(buffer,"Debbie")) {
        _printStringToOutput("Your program always prints \'Debbie\' ...");
        
    }
    if (!strstr(buffer,"Dieter")) {
        _printErrorToOutput("Your program does not output the name given by the input properly.");
        return 77;
    }
    

    
    return 100-_getWarnCount()*3;
}
