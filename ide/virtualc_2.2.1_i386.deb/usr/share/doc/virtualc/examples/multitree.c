/*******************************************************************************/
/* multitree.c - a threading example, plotting a Pythagoras Tree fractal       */
/* ---------------------------------------------------------------------       */
/*                                                                             */
/* This sample is taken from A. Baumann's hands-on Java course on programming: */
/* http://www.unibw.de/etti6/baumann/lehre/grundlagen-der-programmierung       */
/*                                                                             */
/* Adapted to C11 and SDL by D. Pawelczak                                      */
/* Note, Virtual-C IDE Version 1.7 or higher required (larger thread pool!)    */
/*                                                                             */
/*******************************************************************************/

#define COLOR_DEPTH 32
#define SIZE_X 320
#define SIZE_Y 240

/*
 * to better grasp the difference between single & multithreaded, 
 * enable verbose mode - to fasten speed, set VERBOSE to 0!                                                                    
 */

#define VERBOSE 1

/*
 * increasing the MAX_DEPTH (>6) will dramatically slow down the 
 * threaded drawing as the number of threads explode exponentially !
 */

#define MAX_DEPTH 5

/*
 * you can disable threads here, note it is automaically defined if 
 * no ISO C11 threads are supported!
 */

#define NO_THREADS 0


#ifdef MOPVM
#include <sdlite.h>
#else
#include <sdl.h>
#endif

#ifdef __STDC_NO_THREADS__
#undef NO_THREADS
#define NO_THREADS 1
#endif

#include <math.h>
#include <stdint.h>
#if !NO_THREADS
#include <threads.h>
#endif

/* draws a 4 point polygon */
void VDrawQuadrilateral(SDL_Surface *screen, int x0, int y0, int x1, int y1, int x2, int y2, int x3, int y3, Uint32 color);

/* helpers for point calculations */
double CalcCx(double ay, double bx, double by) {
	return bx - (ay - by);
}
double CalcCy(double ax, double bx, double by) {
	return by - (bx - ax);
}
double CalcDx(double ax, double ay, double by) {
	return ax - (ay - by);
}
double CalcDy(double ax, double ay, double bx) {
	return ay - (bx - ax);
}
double CalcEx(double dx, double dy, double cx, double cy, double s){
	return (1 - s) * dx + s * cx + sqrt(s * (1 - s)) * (dy - cy);
}
double CalcEy(double dx, double dy, double cx, double cy, double s) {
	return (1 - s) * dy + s * cy + sqrt(s * (1 - s)) * (cx - dx);
}

#define RED_BITS   16
#define GREEN_BIT  8
#define BLUE_BITS  8
#define COLOR_BIT  8
/* shades the baseColor according to the depth */
uint32_t CreateColorFromDepth(int depth, int maxDepth, uint32_t baseColor) {
	uint32_t brightness = (depth << COLOR_BIT) / maxDepth;
	uint32_t blue = (brightness * (baseColor & 0xff)) >> COLOR_BIT;
	uint32_t green = (brightness * ((baseColor >> COLOR_BIT) & 0xff )) >> COLOR_BIT;
	uint32_t red = (brightness * ((baseColor >> RED_BITS) & 0xff )) >> COLOR_BIT;
	return 0xff000000 | blue | green << GREEN_BIT | red << RED_BITS;
}

/* draws recursively a tree out of squares */
void DrawTree(SDL_Surface *screen, int depth, int maxDepth, int x1, int y1, int x2, int y2, double s, uint32_t baseColor)  {
	double dx = CalcDx(x1, y1, y2);
	double dy = CalcDy(x1, y1, x2);
	double cx = CalcCx(y1, x2, y2);
	double cy = CalcCy(x1, x2, y2);
	uint32_t color = CreateColorFromDepth(depth, maxDepth, baseColor);
	
#if VERBOSE
	printf("Tree at: (%d, %d), (%d, %d)\n", x1, y1, x2, y2);
#endif
	if (depth <= 1) {
		/* draw a single filled square at x1, y1 and x2, y2 */
		VDrawQuadrilateral(screen, x1, y1, x2, y2, (int)cx, (int)cy, (int)dx, (int)dy, color);
	} else {
		VDrawQuadrilateral(screen, x1, y1, x2, y2, (int)cx, (int)cy, (int)dx, (int)dy, color);
		/* calculate next two trees */
		int ex = (int) CalcEx(cx, cy, dx, dy, s);
		int ey = (int) CalcEy(cx, cy, dx, dy, s);
		/* draw left tree */
		DrawTree(screen, depth - 1, maxDepth, (int) dx,  (int) dy, ex, ey, s, baseColor);
		/* draw right tree */
		DrawTree(screen, depth - 1, maxDepth, ex,	ey, (int) cx, (int) cy, s, baseColor);
	} 
}

#if !NO_THREADS

void DrawTreeThreaded(SDL_Surface *screen, int depth, int maxDepth, int x1, int y1, int x2, int y2, double s, uint32_t baseColor);

/* Thread communication struct to pass arguments to the thread */
typedef struct {
	SDL_Surface *screen;
	int depth;
	int maxDepth;
	int x1;
	int y1;
	int x2;
	int y2;
	double s;
	uint32_t baseColor;
} tThreadData;

/* Thread function, that invokes DrawTreeThreaded */
int InvokeDrawTreeThreaded(void* data) {
	tThreadData *com = data;
	DrawTreeThreaded(com->screen, com->depth, com->maxDepth, com->x1, com->y1, com->x2, com->y2, com->s, com->baseColor);	
	free(data);
	return 0;
}

void DrawTreeThreaded(SDL_Surface *screen, int depth, int maxDepth, int x1, int y1, int x2, int y2, double s, uint32_t baseColor)  {
	double dx = CalcDx(x1, y1, y2);
	double dy = CalcDy(x1, y1, x2);
	double cx = CalcCx(y1, x2, y2);
	double cy = CalcCy(x1, x2, y2);
	uint32_t color = CreateColorFromDepth(depth, maxDepth, baseColor);
	
#if VERBOSE
	printf("Tree at: (%d, %d), (%d, %d)\n", x1, y1, x2, y2);
#endif
	if (depth <= 1) {
		/* draw a single filled square at x1, y1 and x2, y2 */
		VDrawQuadrilateral(screen, x1, y1, x2, y2, (int)cx, (int)cy, (int)dx, (int)dy, color);
	} else {
		thrd_t id1, id2;
		
		/* calculate next two trees */
		int ex = (int) CalcEx(cx, cy, dx, dy, s);
		int ey = (int) CalcEy(cx, cy, dx, dy, s);

/*		instead of
 *		DrawTree(screen, depth - 1, maxDepth, (int) dx,  (int) dy, ex, ey, s, baseColor);
 *		we start a new thread.
 */
		
		tThreadData *data = malloc(sizeof(tThreadData));
        if (data) {
            data->screen = screen;
            data->depth = depth - 1;
            data->maxDepth = maxDepth;
            data->x1 = (int) dx;
            data->y1 = (int) dy;
            data->x2 = ex;
            data->y2 = ey;
            data->s = s;
            data->baseColor = baseColor & 0xff | 0xff00;
            /*
             * there might be no thread available, so repeat until thrd_success
             */
            while (thrd_create(&id1, InvokeDrawTreeThreaded, data) != thrd_success)
                thrd_yield();
        }
/*		instead of
 *		DrawTree(screen, depth - 1, maxDepth, ex, ey, (int) cx, (int) cy, s, baseColor);
 *		we start a new thread.
 */
		data = malloc(sizeof(tThreadData));
        if (data) {
            data->screen = screen;
            data->depth = depth - 1;
            data->maxDepth = maxDepth;
            data->x1 = ex;
            data->y1 = ey;
            data->x2 = (int)cx;
            data->y2 = (int)cy;
            data->s = s;
            data->baseColor = baseColor & 0xff | 0xff0000;
            /*
             * there might be no thread available, so repeat until thrd_success
             */
            while (thrd_create(&id2, InvokeDrawTreeThreaded, data) != thrd_success)
                thrd_yield();
            
        }
		VDrawQuadrilateral(screen, x1, y1,  x2, y2, (int)cx, (int)cy, (int)dx, (int)dy, color);
        thrd_join(id1, NULL); /* left tree complete? */
        thrd_join(id2, NULL); /* right tree complete? */
	}
}

#endif

int main(int argc, char**argv) {
 	
	if (SDL_Init(SDL_INIT_VIDEO) != 0)
		return 1;
	
    atexit(SDL_Quit);

    SDL_Surface *screen = SDL_SetVideoMode(SIZE_X, SIZE_Y, COLOR_DEPTH, 0);

	if (screen)	{

		SDL_WM_SetCaption("Multithreaded Pythagoras Tree", NULL);

		/* calculate tree positions */
		int bigWidth = SIZE_X / 8;
		int smallWidth = bigWidth / 2;
		int posX = SIZE_X * 3 / 6;
		int posX1 = SIZE_X * 2 / 6 - bigWidth;
		int posX2 = SIZE_X * 4 / 6 + bigWidth;;
		int posY = SIZE_Y * 5 / 6;
		int posY1 = SIZE_Y * 5 / 6 + smallWidth;
		int posY2 = SIZE_Y * 3 / 6 - smallWidth;
			
		DrawTree(screen, MAX_DEPTH, MAX_DEPTH, posX, posY, posX + bigWidth, posY, 0.35, 0xff);
		SDL_Flip(screen);

#if !NO_THREADS
		/* draw again, now threaded */
		DrawTreeThreaded(screen, MAX_DEPTH, MAX_DEPTH, posX, posY, posX + bigWidth, posY, 0.35, 0xff);
		SDL_Flip(screen);
		
		/* draw unthreaded on the right */
		DrawTree(screen, MAX_DEPTH, MAX_DEPTH, posX1, posY1, posX1 + smallWidth, posY1, 0.35, 0xffff00);
		SDL_Flip(screen);

		/* draw threaded on the left */
		DrawTreeThreaded(screen, MAX_DEPTH, MAX_DEPTH, posX2, posY2, posX2 + smallWidth, posY2, 0.35, 0xffff00);
		SDL_Flip(screen);
#endif
		/* now wait for a key stroke or a mouse click */
		SDL_Event ev;
		do {
			SDL_WaitEvent(&ev);
			SDL_Flip(screen);
		} while(ev.type != SDL_KEYDOWN && ev.type != SDL_MOUSEBUTTONDOWN && ev.type != SDL_QUIT);
		
	} else
		printf("Error initializing the SDL video mode ...\n");
	return 0;

}



/*************************************************************************/


// taken from sdlsample.c
void VSetPixel(SDL_Surface *surface, int x, int y, Uint32 pixel) { 
	Uint8 *target_pixel = (Uint8 *)surface->pixels + y * surface->pitch + x * 4;
    *(Uint32 *)target_pixel = pixel;
}

/* The graphic functions are taken from the VScreen.lib (c) 2005-2009 by D. Pawelczak */

// Extremely Fast Line Algorithm Var C (Addition)
// Copyright 2001-2, By Po-Han Lin
// Freely useable in non-commercial applications as long as credits 
// to Po-Han Lin and link to http://www.edepot.com is provided in source 
// code and can been seen in compiled executable.  Commercial 
// applications please inquire about licensing the algorithms.
//
// Lastest version at http://www.edepot.com/phl.html

// THE EXTREMELY FAST LINE ALGORITHM Variation C (Addition)
// modified by D. Pawelczak


void VLine(SDL_Surface *surface, int x, int y, int x2, int y2, Uint32 c) 
{
#if VERBOSE
	printf("Line: (%d, %d)-(%d, %d)\n", x, y, x2, y2);
#endif

	VSetPixel(surface, x, y, c);
	VSetPixel(surface, x2, y2, c);
	typedef enum { false, true } bool;
	bool yLonger = false;
	
	int shortLen= y2 - y;
	int longLen= x2 - x;
	if (abs(shortLen) > abs(longLen)) {
		int swap = shortLen;
		shortLen = longLen;
		longLen = swap;
		yLonger = true;
	}
	
	int endVal=longLen;

	int incrementVal = longLen < 0 ? -1 : 1;

	if (incrementVal < 0) {
		longLen = -longLen;
	}
	double decInc = longLen == 0 ? shortLen : (double)shortLen / (double)longLen;
	double j=0.0;
	if (yLonger) {
		for (int i = 0; i != endVal; i += incrementVal) {
			VSetPixel(surface, x + (int) j, y + i, c);
			j += decInc;
		}
	} else {
		for (int i = 0; i != endVal; i += incrementVal) {
			VSetPixel(surface, x + i, y + (int) j, c);
			j += decInc;
		}
	}
}

static void FillBottomFlatTriangle(SDL_Surface* surface, int x1, int y1, int x2, int y2, int x3, int y3, Uint32 c) {
#if VERBOSE
	printf("BotTriangle Points: (%d,%d),(%d,%d),(%d,%d)\n",
		x1, y1, x2, y2, x3, y3);
#endif
				  
	double invSlope1 = (double)(x2 - x1) / (y2 - y1);
	double invSlope2 = (double)(x3 - x1) / (y3 - y1);
			
	double curx1 = x1;			  
	double curx2 = x1;
				
	for (int scanLineY = y1; scanLineY <= y2; ++scanLineY) {
		VLine(surface, (int)curx1, scanLineY, (int)curx2, scanLineY, c);
		curx1 += invSlope1;
		curx2 += invSlope2;
	}
}

static void FillTopFlatTriangle(SDL_Surface*surface, int x1, int y1, int x2, int y2, int x3, int y3, Uint32 c) {
#if VERBOSE
	printf("TopTriangle Points: (%d,%d),(%d,%d),(%d,%d)\n",
		x1, y1, x2, y2, x3, y3);
#endif

	double invSlope1 = (double)(x3 - x1) / (y3 - y1);
	double invSlope2 = (double)(x3 - x2) / (y3 - y1);
	
	double curx1 = x3;
	double curx2 = x3;

	for (int scanLineY = y3; scanLineY > y1; --scanLineY) {
		VLine(surface, (int)curx1, scanLineY, (int)curx2, scanLineY, c);
		curx1 -= invSlope1;
		curx2 -= invSlope2;
  	}
}


void VFillTriangle(SDL_Surface*surface, int x1, int y1, int x2, int y2, int x3, int y3, Uint32 c) {
	int swy = 0;
	int swx = 0;
#if VERBOSE
	printf("Triangle Points: (%d,%d),(%d,%d),(%d,%d)\n",
		x1, y1, x2, y2, x3, y3);
#endif
	
	if (x1 == x2 && y1 == y2 && x2 == x3 && y2 == y3) {
		VSetPixel(surface, x1, y2, c);
		return;
	}

	if (y1 > y2) {
		swy = y2;
		y2 = y1;
		y1 = swy;
		swx = x2;
		x2 = x1;
		x1 = swx;
	}	
 	if (y2 > y3) {
		swy = y3;
		y3 = y2;
		y2 = swy;
		swx = x3;
		x3 = x2;
		x2 = swx;
 	 	if (y1 > y2) {	
			swy = y2;
			y2 = y1;
			y1 = swy;
			swx = x2;
			x2 = x1;
			x1 = swx;
		}	
	}	
	if (y2 == y3) {
    	FillBottomFlatTriangle(surface, x1, y1, x2, y2, x3, y3, c);
	}else 
	if (y1 == y2) {
		FillTopFlatTriangle(surface, x1, y1, x2, y2, x3, y3, c);
	} else {
    	int x4 = (int)(x1 + ((double)(y2 - y1) / (double)(y3 - y1)) * (x3 - x1));
		int y4 = y2;
		FillBottomFlatTriangle(surface, x1, y1 , x2, y2, x4, y4, c);
		FillTopFlatTriangle(surface, x2, y2, x4, y4, x3, y3, c);
	}
}

void VDrawQuadrilateral(SDL_Surface *screen, int x0, int y0, int x1, int y1, int x2, int y2, int x3, int y3, Uint32 color) {
#if VERBOSE
	printf("QL Points: (%d,%d),(%d,%d),(%d,%d),(%d,%d)\n",
		x0, y0, x1, y1, x2, y2, x3, y3);
#endif
	VFillTriangle(screen, x0, y0, x2, y2, x3, y3, color);
	VFillTriangle(screen, x0, y0, x1, y1, x2, y2, color);
}
