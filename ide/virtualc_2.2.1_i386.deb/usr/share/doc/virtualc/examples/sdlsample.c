/*******************************************************************************************************************************************/
/* SDLSample.c - a simple SDL example plotting random circles                                                                              */
/* ----------------------------------------------------------                                                                              */
/*                                                                                                                                         */
/* This sample is taken from "SDL:Tutorials:Drawing and Filling Circles"                                                                   */
/* by Antonimo, Celdecea, et al. See online at the Game Programming Wiki:                                                                  */
/* http://content.gpwiki.org/index.php/SDL:Tutorials:Drawing_and_Filling_Circles                                                           */
/* Slightly adapted (see remarks) to sdlite by D. Pawelczak                                                                                */
/*                                                                                                                                         */
/*                                                                                                                                         */
/* GNU Documentation License: http://upload.wikimedia.org/wikipedia/de/1/1d/GNU_Free_Documentation_License_Version_1.2_dreispaltig.pdf     */
/*******************************************************************************************************************************************/

#include <sdlite.h> // required for sdlite 
#include <math.h>

/* 
* This is a 32-bit pixel function created with help from this
* website: http://www.libsdl.org/intro.en/usingvideo.html
*
* You will need to make changes if you want it to work with
* 8-, 16- or 24-bit surfaces.  Consult the above website for
* more information.
*/
void set_pixel(SDL_Surface *surface, int x, int y, Uint32 pixel) 
{ 
	Uint8 *target_pixel = (Uint8 *)surface->pixels + y * surface->pitch + x * 4;
    *(Uint32 *)target_pixel = pixel;
}

/* 
* This is an implementation of the Midpoint Circle Algorithm 
* found on Wikipedia at the following link:
*
*   http://en.wikipedia.org/wiki/Midpoint_circle_algorithm
*
* The algorithm elegantly draws a circle quickly, using a
* set_pixel function for clarity.
*/
void draw_circle(SDL_Surface *surface, int n_cx, int n_cy, int radius, Uint32 pixel) 
{
	double error = (double) -radius;
    double x = (double)radius - 0.5;
    double y = (double)0.5;
    double cx = n_cx - 0.5;
    double cy = n_cy - 0.5;
    while (x >= y)
    {
        set_pixel(surface, (int)(cx + x), (int)(cy + y), pixel);
        set_pixel(surface, (int)(cx + y), (int)(cy + x), pixel);

        if (x != 0)
        {
        	set_pixel(surface, (int)(cx - x), (int)(cy + y), pixel);
            set_pixel(surface, (int)(cx + y), (int)(cy - x), pixel);
        }

        if (y != 0)
        {
            set_pixel(surface, (int)(cx + x), (int)(cy - y), pixel);
            set_pixel(surface, (int)(cx - y), (int)(cy + x), pixel);
        }

        if (x != 0 && y != 0)
        {
            set_pixel(surface, (int)(cx - x), (int)(cy - y), pixel);
            set_pixel(surface, (int)(cx - y), (int)(cy - x), pixel);
        }

        error += y;
        ++y;
        error += y;

        if (error >= 0)
        {
            --x;
            error -= x;
            error -= x;
        }
    }
}

/* SDL_Surface 32-bit circle-fill algorithm without using trig
*
* While I humbly call this "Celdecea's Method", odds are that the 
* procedure has already been documented somewhere long ago.  All of
* the circle-fill examples I came across utilized trig functions or
* scanning neighbor pixels.  This algorithm identifies the width of
* a semi-circle at each pixel height and draws a scan-line covering
* that width.  
*
* The code is not optimized but very fast, owing to the fact that it
* alters pixels in the provided surface directly rather than through
* function calls.
*
* WARNING:  This function does not lock surfaces before altering, so
* use SDL_LockSurface in any release situation.
*/

#define BPP 4

void fill_circle(SDL_Surface *surface, int cx, int cy, int radius, Uint32 pixel) 
{ 

    double r = (double)radius;
    double dy = 1;

    for ( dy = 1; dy <= r; dy += 1.0)
    {
        // This loop is unrolled a bit, only iterating through half of the
        // height of the circle.  The result is used to draw a scan line and
        // its mirror image below it.
        // The following formula has been simplified from our original.  We
        // are using half of the width of the circle because we are provided
        // with a center and we need left/right coordinates.
        double dx = floor(sqrt((2.0 * r * dy) - (dy * dy)));
        int x = (int)(cx - dx);
        // Grab a pointer to the left-most pixel for each half of the circle
        Uint8 *target_pixel_a = (Uint8 *)surface->pixels + ((int)(cy + r - dy)) * surface->pitch + x * BPP;
        Uint8 *target_pixel_b = (Uint8 *)surface->pixels + ((int)(cy - r + dy)) * surface->pitch + x * BPP;
        
        for (; x <= (int)(cx + dx); x++)
        {
            *(Uint32 *)target_pixel_a = pixel;
            *(Uint32 *)target_pixel_b = pixel;
            target_pixel_a += BPP;
            target_pixel_b += BPP;
        }
    }
} 

#define WIDTH     640
#define HEIGHT    480
#define MAX_RADIUS 64
#define RED_BITS   16
#define GREEN_BITS  8
/* Test application */
int main(int argc, char *argv[]) { 
    static const int width = WIDTH;
    static const int height = HEIGHT;
    static const int max_radius = MAX_RADIUS;
	
	if (SDL_Init(SDL_INIT_VIDEO) != 0)
		return 1;

    atexit(SDL_Quit);

    SDL_Surface *screen = SDL_SetVideoMode(width,
		 height, 0, SDL_DOUBLEBUF);

    while(screen)
    {
 	    int x = 0, y = 0, r = 0, c = 0;
        SDL_Event event; 
        while(SDL_PollEvent(&event))
        {
            if(event.type == SDL_QUIT)
                return 0;
        }
        x = rand() % (width - 4) + 2; /* for C, variables need to be moved to the beginning of the block ... */
        y = rand() % (height - 4) + 2;
        r = rand() % (max_radius - 10) + 10;
        c = ((rand() % 0xff) << RED_BITS) + \
            	((rand() % 0xff) << GREEN_BITS) + \
            	(rand() % 0xff);

        if (r >= 4)
        {
            if (x < r + 2)
                x = r + 2;
            else 
			if (x > width - r - 2)
				x = width - r - 2;
            if (y < r + 2)
               	y = r + 2;
            else 
				if (y > height - r - 2)
               		y = height - r - 2;
        }
        /* draw on 1st buffer */
        SDL_LockSurface(screen);

        fill_circle(screen, x, y, r, 0xff000000 + c);
        draw_circle(screen, x, y, r, 0xffffffff);
        SDL_UnlockSurface(screen); //SDL_FreeSurface(screen);  /* the original tutorial uses free surface here - this won't work under sdlite, as it will free the associated pointers ... */

		SDL_Flip(screen);
        /* draw on 2nd buffer - adapted by D. Pawelczak to draw the same circle on both buffers (sdlite is not as fast as real sdl ... */

	    SDL_LockSurface(screen);
        fill_circle(screen, x, y, r, 0xff000000 + c);
        draw_circle(screen, x, y, r, 0xffffffff);
        SDL_UnlockSurface(screen);
        SDL_Flip(screen); 
    }
	/* error, screen == NULL */
    return 2;
} 