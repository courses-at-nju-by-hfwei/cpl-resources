#ifndef _MOP_VMEX
#define _MOP_VMEX
/***************************************************************************
	SimpleC - A Simple C Compiler
    (c) 2008-2015 by Dieter R. Pawelczak

 ****************************************************************************
 
 mopvmex.h - monitoring functions for the MOP virtual machine 

 ****************************************************************************

 returns internal run-time information for code analysis during run-time
 /!!! works only during execution in the MOP VM! !!!/

 ****************************************************************************/

#ifdef MOPVM
#include <stddef.h>
 
/* Execution Limit Exception ***********************************************/

// The execution limit execption allows to stop and continue execution, in case of a dead lock:
// in case of the maximum number of operations (execution limit) reached,
// the execution of the current function is interrupted. The execution continues
// immediately after the function call in which the execption occurred.
// The execution limit exception can occur only once. For further testing, the 
// execution limit has to be explicitly reset.


/* set the maximum number of operations allowed for the following function call;
   _setExecutionLimit(0) will disable the execution counter and reset any flag previously set by the execution counter  */
void _setExecutionLimit(int i);

/* returns true, if the execution limit was reached; */
int _executionLimitReached(void);

/* returns the number of operations, which have been executed since the last call to _setExecutionLimit() */
int _getExecutionCount(void);

/* returns the line number of the function, that causes an execution limit execption  */
int _getExecutionLimitLine(void);

/* copies the name of the function, that causes the execption */
int _getExecutionLimitFuncName(char* name);

/* copies the name of the module, that causes the execption */
int _getExecutionLimitModuleName(char* name);

/* Illegal Memory Access Exception ***********************************************/


// any invalid command (usually resulting in a fatal error exit) is caught
// in the following function call. Execution is resumed directly after the
// function call
// Illegal Memory Access Exception is enabled in case an executionLimit != 0 is set

/* returns true, if the execution limit was reached; */
int _memoryExceptionReached(void);


/* Testing *****************************************************************/

/* relinks a function dynamically to another function (works only in Mopcheck target) */
void _relinkSymbol(void(*oldFunction)(void),void(*newFunction)(void));

/* queries attributes (key) from the compiler/linker and copies to (dest) */
/* currently supported attributes are: (works only under taskcontroller)
 - globals:   number of global variables
 - functions: total number of functions
 - floatOps:  total number of floating point operations
 - maxDepth:  max loop depth
 - calls:     total number of function calls
 - xxx_Calls: number of functions calls inside the function named xxx
 - XXXX:      value of a #define, which is an int constant, e.g. #define XXXX 10
 */
void _queryAttributes(char*dest,const char*key);

/* overloaded function to query int values in compiler/linker attributes */
int _queryIntAttributes(const char*key);

/* checks, if the current editor window contains the given regular expression */
int _editorContains(const char* regex);

/* represents exit() and abort() to return to the test frame work */ 
void _exitmop_(int code);


/* Statistic Functions ***********************************************/

// statistics functions are enabled in case an executionLimit != 0 is set


/* resets the stat counter */
void _resetVMStatistics(void);

/* reads the number of primitive operations */
int _readVMprimOperations(int *divMod, int *mul, int *subAdd, int *logic,
						  int *condBranch, int *gotos, int* calls);
/* reads the number of memory-operations */
int _readVMmemOperations(int *write, int *read);



/* Heap-Handling *****************************************************************/

/* returns the amount of memory allocated for ptr on the heap */
size_t _ptrHeapSize(void *ptr);

/* return the number of memory blocks allocated on the heap */
int _heapBlockCount(void);

/* returns a pointer to an allocated memory block on the heap, the index runs from 0..heapBlockCount-1 */
void* _heapElement(int index);

/* checks, if the heap is still valid NOTE: not yet implemented, always returns true */
int _heapValid(void);
/* resets the heap segment (all data on heap is lost, pointers are invalid */
int _resetHeap(void);
/* prints an hex dump of a heap-element, if it exists on the heap, otherwise it does nothing */
void _dumpHeapElement(unsigned char* ptr);




/* Utility Functions *************************************************************/

/* prints the current call stack from depth ... to main */
int _printCallStack(int depth);

/* prints the string str to the output windows of the compiler gui */
int _printStringToOutput(const char* str);
int _printStringToOutputArgs(const char* str, ...); /* variadic version */
/* prints a warning to the output windows of the compiler gui, increases the warnCount attribute */
int _printWarningToOutput(const char* str);
int _printWarningToOutputArgs(const char* str, ...);
/* prints an fatal error to the output windows of the compiler gui, increases fatal count  */
int _printFatalToOutput(const char* str);
int _printFatalToOutputArgs(const char* str, ...);
/* prints an error to the output windows of the compiler gui, increases error count */
int _printErrorToOutput(const char* str);
int _printErrorToOutputArgs(const char* str, ...);
/* returns the number of warnings, i.e. the warnCount attribute */
int _getWarnCount(void);
/* returns the number of fatal exceptions, i.e. the warnCount attribute */
int _getFatalCount(void);
/* returns the number of errors/exceptions, i.e. the warnCount attribute */
int _getErrorCount(void);
/* clears all counters and prints FUNCTIONAL TEST to output window */
int _initMopCheck(void);
/* redirects stdout to a string buffer */
void _redirectStdout(char* buffer, size_t sizeOfBuffer);
/* redirects stdin to a string buffer */
void _redirectStdin(const char* buffer, size_t len);
/* relinks the data segment of the program under test */
void _relinkDataSegment(void);
/* removes static links (restores relinkSymbol actions) */
void _relinkFunctions(void);
/* in case, an exception occurred, the exception plus the string str are printed in the output windows of the compiler gui */
int _printExceptionToOutput(const char* name);
/* in case, an exception or execution limit execption occurred, the corresponding string is print (execption plus stack trace), the execution limit is reset to 0. Returns 1 for an exception, 2 for a limit and 0 on success */
int _printFault(const char* limit, const char * execption);
/* checks, if a string contains the following reg expression */
int _containsRegEx(const char* str, const char* regEx);
/* searches a reg expression inside a string */
char* _strregex(const char* str, const char* regEx);
/* evaluates a local variable not visible on the stack */
char* _getInvalidVariableValue(char* buffer,
                              size_t buf_size, int index, const char* name);

/* TSC-Internal functions *************************************************************/

/* sets the current test case */
int _setTestCaseNumber(int testCaseNo);
/* increments the current test  number */
void _setTestNumber(int testNo);
/* marks all tests as passed in the current test case, unless they failed */
void _updateTestCase(void);

#else
#error target is not the MOPVM!
#endif

#endif
