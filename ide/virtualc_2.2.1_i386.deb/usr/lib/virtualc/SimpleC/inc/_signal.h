#ifndef _signal_h
#define _signal_h
/***************************************************************************
	SimpleC - A Simple C code generator
    (c) 2008 by Dieter R. Pawelczak 

 ****************************************************************************

 Header File signal.h - as defined in C11 - section 7.14

 ****************************************************************************/

#define SIG_ERR (void*) 0  /* equal to NULL */
#define SIG_DFL __sighandler
#define SIG_IGN __sigignore 
#define SIGSEGV 1
#define SIGABRT 2
#define SIGFPE  3
#define SIGILL  4
#define SIGINT  5
#define SIGTERM 6
/* Non ISO-Compliant: POSIX Add-on: */
#define SIGUSR1 8
#define SIGUSR2 9


extern int errno;
typedef void (*fpHandler)(int signo);

extern int raise(int sig);
//extern void (*signal(int sig, void (*fpHandler)(int signo)))(int sigr);
extern fpHandler signal(int sig, fpHandler);

extern void __sighandler(int);
extern void __sigignore(int);
#endif
