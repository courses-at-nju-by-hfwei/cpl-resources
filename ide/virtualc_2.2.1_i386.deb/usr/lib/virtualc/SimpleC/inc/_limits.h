#ifndef _LIMITS_H
#define _LIMITS_H

/***************************************************************************
	SimpleC - A Simple C code generator
    (c) 2008 by Dieter R. Pawelczak 

 ****************************************************************************

 Header File limits.h - as defined in C11 section 7.10
 ToDo: add type long long int
 ****************************************************************************/

#define UCHAR_MAX 255
#define USHRT_MAX 65536
#define SCHAR_MIN -128
#define SCHAR_MAX 127
#define SHRT_MIN -32768
#define SHRT_MAX 32767
#define CHAR_MIN -128
#define CHAR_MAX 128
#define ULONG_MAX 4294967295UL
#define UINT_MAX 4294967295U
#define LONG_MIN -2147483648L
#define LONG_MAX 2147483647L
#define INT_MIN -2147483648
#define INT_MAX  2147483647
#define SIZE_MAX ULONG_MAX
/* ToDo for long long */
#define ULLONG_MAX ULONG_MAX
#define LLONG_MIN LONG_MIN
#define LLONG_MAX LONG_MAX

#undef PTRDIFF_MIN
#undef PTRDIFF_MAX
#define PTRDIFF_MIN INT_MIN
#define PTRDIFF_MAX INT_MAX

#define CHAR_BIT 8
#define SHORT_BIT 16
#define INT_BIT   32
#define LONG_BIT  32
#define LONG_LONG_BIT 32 /* ToDo ! */
#endif