#ifndef _STDALIGN_H
#define _STDALIGN_H
/**************************************************************************
	SimpleC - A Simple C code generator
    (c) 2008 by Dieter R. Pawelczak 

 ****************************************************************************

 Header File stdalign.h - as defined in C11 section 7.15
 
 ****************************************************************************/

#define alignas _Alignas
#define __alignas_is_defined 1
#define alignof _Alignof
#define __alignof_is_defined 1

#endif