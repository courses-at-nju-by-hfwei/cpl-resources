/**************************************************************************
	SimpleC - A Simple C code generator
    (c) 2008 by Dieter R. Pawelczak 

 ****************************************************************************

 Header File assert.h - as defined in C11 Section 7.2

 ****************************************************************************/

#ifndef static_assert
#define static_assert _Static_assert
#endif
#ifdef NDEBUG
#undef assert
#define assert(ignore) ((void)0)
#else
extern void _forwardAssert(char *text, long line, char* file, char* function);
#undef assert
#define assert(expr) ((expr) ? ((void)0) : (_forwardAssert(#expr, __LINE__, __FILE__, __FUNCTION__)))
#endif
