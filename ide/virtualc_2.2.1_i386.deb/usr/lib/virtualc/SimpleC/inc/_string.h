#ifndef _string_h
#define _string_h

/***************************************************************************
	SimpleC - A Simple C code generator
    (c) 2008 by Dieter R. Pawelczak 

 ****************************************************************************

 Header File string.h as defined in C11 Section 7.24

 ****************************************************************************/

#include <stddef.h>


#ifdef _M_IX86
#define __call_conf __fast
#else
#define __call_conf
#endif

void *memcpy(void * restrict dest, const void * restrict src, size_t n);
#ifdef _MANAGED
/* Note: _memcpy_asm will be coded as CIL instruction cpyblk */
void *_memcpy_asm(void * restrict dest, const void * restrict src, size_t n);
#define memcpy _memcpy_asm
#endif

void *memmove(void *dest, const void *src, size_t n);
__call_conf char *strcpy(char * restrict dest, const char * restrict src);
char *strncpy(char * restrict dest, const char * restrict src, size_t n);
__call_conf char *strcat(char * restrict dest, const char * restrict src);
char *strncat(char * restrict dest, const char * restrict src, size_t n);
int memcmp(const void *s1, const void *s2, size_t n);
__call_conf int strcmp(const char *s1, const char *s2);
int strcoll(const char *s1, const char *s2);
int strncmp(const char *s1, const char *s2, size_t n);
size_t strxfrm(char * restrict s1, const char * restrict s2, size_t n);
void *memchr(const void *s, int c, size_t n);
char *strchr(const char *s, int c);
size_t strcspn(const char *s1, const char *s2);
char *strpbrk(const char *s1, const char *s2);
char *strrchr(const char *s, int c);
size_t strspn(const char *s1, const char *s2);
__call_conf  char *strstr(const char *s1, const char *s2);
char *strtok(char * restrict s1, const char * restrict s2);
char *strtok_s(char* restrict s1, rsize_t* restrict s1max, const char* restrict s2, char** restrict ptr);
void *memset(void *dest, int c, size_t n);
char *strerror(int errnum);
__call_conf size_t strlen(const char *s);
/* neither ISO nor POSIX - a helper in slibc */
__call_conf char *strupr(char* dest);



#endif