
/***************************************************************************
	SimpleC - A Simple C Compiler
    (c) 2008-2011 by Dieter R. Pawelczak 

 ****************************************************************************
   
   <threads.h> - ISO C11 Sec. 7.26

 ****************************************************************************/

#include <time.h> /* see Sec.7.26.1 */


#define thread_local _Thread_local
#define ONCE_FLAG_INIT 0
#define TSS_DTOR_ITERATIONS 99999 /* infinite, as destructors are hold in a linked list */


/* thread function prototype like: int ThreadFunc(void* arg); */
typedef int (*thread_start_t)(void*arg);

/* thread handle */
typedef size_t thrd_t;

/* condition handle */
typedef size_t cnd_t;

/* thread specific storage handle */
typedef void* tss_t;

/* mutex handle */
typedef size_t mtx_t;

/* flag for call_once */
typedef size_t once_flag;

/* mutex */
typedef enum { mtx_plain, mtx_recursive, mtx_timed } mtx_type;

/* thread */
typedef enum { thrd_success, thrd_nomem, thrd_error, thrd_busy, thrd_timeout } thrd_type;


/* creates a thread starting at func with optional arg */
int thrd_create(thrd_t *thread, thread_start_t func, void* arg);

/* terminates a thread with a given return value */
_Noreturn void thrd_exit(int res);

/* returns the current thread id */
thrd_t thrd_current(void);

/* returns 0 in case both threads are euqal */
int thrd_equal(thrd_t a, thrd_t b);

/* delays execution for at least specified period */
int thrd_sleep(const struct timespec *duration, const struct timespec *remaining);

/* frees threads CPU time for other threads to run */
void thrd_yield(void);

/* waits for another thread to terminate and optionally returns its exit code */
int thrd_join(thrd_t thr, int *res);

/* initializes a mutex */
int mtx_init(mtx_t *mtx, mtx_type type);

/* frees a mutex */
void mtx_destroy(mtx_t *mtx);

/* locks a mutex */
int mtx_lock(mtx_t *mtx);

/* trys for a given time to lock the mutex */
int mtx_timedlock(mtx_t *restrict mtx,
                  const struct timespec *restrict ts);

/* trys to lock the mutex */
int mtx_trylock(mtx_t *mtx);


/* unlocks a mutex */
int mtx_unlock(mtx_t *mtx);

/* initializes a condition */
int cnd_init(cnd_t *cond);

/* frees a condition */
void cnd_destroy(cnd_t *cond);

/* signals a condition */
int cnd_signal(cnd_t *cond);

/* broadcasts a condition to all blocked threads */
int cnd_broadcase(cnd_t *cond);

/* temporally blocks thread for a condition  */
int cnd_timedwait(cnd_t *restrict cond,
                  mtx_t *restrict mtx,
                  const struct timespec *restrict ts);

/* blocks thread for a condition  */
int cnd_wait(cnd_t *restrict cond,
                  mtx_t *restrict mtx);


