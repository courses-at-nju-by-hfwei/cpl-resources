#ifndef _STDBOOL_H
#define _STDBOOL_H
/**************************************************************************
	SimpleC - A Simple C code generator
    (c) 2008 by Dieter R. Pawelczak 

 ****************************************************************************

 Header File stdbool.h - as defined in C11 section 7.18 

 ****************************************************************************/

#ifdef __STDC_VERSION__
#if __STDC_VERSION__ >= 199901

typedef _Bool bool;

#else

typedef int bool;

#endif
#endif

#define __bool_true_false_are_defined 1
#define false 0
#define true  1


#endif