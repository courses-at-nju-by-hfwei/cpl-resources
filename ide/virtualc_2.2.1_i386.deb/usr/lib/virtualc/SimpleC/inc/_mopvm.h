#ifndef _MOP_VM
#define _MOP_VM
/***************************************************************************
	SimpleC - A Simple C Compiler
    (c) 2008-2011 by Dieter R. Pawelczak 

 ****************************************************************************
 
 mopvm.h - accessing virtual hardware of the MOP virtual machine

 ****************************************************************************

 
 ****************************************************************************/

#ifdef MOPVM

 
typedef struct { 
	unsigned char blue, green, red, alpha;
} tColor;

tColor* VOpenVirtualScreen(int x, int y);

#else
#error target is not the MOPVM!
#endif

#endif