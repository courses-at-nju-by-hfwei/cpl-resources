#ifndef _SDLITE_H
#define _SDLITE_H


/*****************************************************************************/
/* SDLITE.H - a lightweight stub of the SDL-Library for the SimpleC-Compiler */
/*****************************************************************************/
/* File:         SDLITE.H                                                    */
/* Description:  - a stub for the SDL-Library (Simple Directmedia Layer      */
/*                 by Sam Lantinga) Version 1.2, see http://www.libsdl.org   */                           
/*               - allows usage of _some_ SDL-Function from within the       */
/*                 VirtualC-IDE.                                             */
/*               Current limits are:                                         */
/*               - supports Video (only 32-Bit video & import of 24 bit .BMP)*/
/*               - supports Events (only timer, keyboard & mouse)            */
/*               - dummy for Audio (only empty functions)                    */
/*****************************************************************************/
/* Author:       Dieter Pawelczak                                            */
/* Version:		 1.01 - September 2015        							     */
/* License:      Redistribution and use in source and binary forms,          */
/*               with or without modification, are permitted provided that   */
/*               the following conditions are met:                           */
/*               - use for educational or non-commercial purpose             */
/*               - reproduction of the copyright notice.                     */
/*****************************************************************************/
/* Note:                                                                     */
/* The SimpleC-Compiler should be able to directly work with the SDL-Headers,*/
/* if you specify DECLSPEC and SDLCALL properly. This stub provides only a   */
/* small set of the SDL-Headers, but these functions are directly supported  */
/* by the Virtual-C IDE. This is the main reason for providing this stub.    */
/* Outside the Virtual-C IDE or when generating a standalone executable, the */
/* library SDL.dll (Version 1.2.*) is required in the application path.      */
/*****************************************************************************/

#ifndef SIMPLEC
#error This file compiles only with SimpleC-Compiler - for other compiler use #include "SDL.h" instead.
#endif


#ifdef MOPVM
#define FUNC_IMPORT
#define SDL_RWFromFile fopen
#define SDL_RWops FILE
#else // Target x86 or .NET
#define FUNC_IMPORT "SDL" __cdecl
#define SDL_RWops void
extern FUNC_IMPORT SDL_RWops *SDL_RWFromFile(char* file, char* mode); 
#endif

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

/* reuired SDL-TYPES */

typedef int8_t		Sint8;
typedef uint8_t		Uint8;
typedef int16_t		Sint16;
typedef uint16_t	Uint16;
typedef int32_t		Sint32;
typedef uint32_t	Uint32;

/* SDL_Init ****************************************************************/

#define	SDL_INIT_TIMER		0x00000001
#define SDL_INIT_AUDIO		0x00000010
#define SDL_INIT_VIDEO		0x00000020
#define SDL_INIT_CDROM		0x00000100   /* subsystem is not supported in VC-IDE */
#define SDL_INIT_JOYSTICK	0x00000200   /* subsystem is not supported in VC-IDE */

extern FUNC_IMPORT int SDL_Init(Uint32 flags);
extern FUNC_IMPORT int SDL_InitSubSystem(Uint32 flags);
extern FUNC_IMPORT void SDL_QuitSubSystem(Uint32 flags);
extern FUNC_IMPORT void SDL_Quit(void);

/* SDL Video ***************************************************************/

typedef struct SDL_Rect {
	Sint16 x, y;
	Uint16 w, h;
} SDL_Rect;

typedef struct SDL_Color {
	Uint8 r;
	Uint8 g;
	Uint8 b;
	Uint8 unused;
} SDL_Color;
#define SDL_Colour SDL_Color

typedef struct SDL_Palette {
	int       ncolors;
	SDL_Color *colors;
} SDL_Palette;

typedef struct SDL_PixelFormat {
	SDL_Palette *palette;
	Uint8  BitsPerPixel;
	Uint8  BytesPerPixel;
	Uint8  Rloss;
	Uint8  Gloss;
	Uint8  Bloss;
	Uint8  Aloss;
	Uint8  Rshift;
	Uint8  Gshift;
	Uint8  Bshift;
	Uint8  Ashift;
	Uint32 Rmask;
	Uint32 Gmask;
	Uint32 Bmask;
	Uint32 Amask;
	Uint32 colorkey; 
	Uint8  alpha;
} SDL_PixelFormat;

typedef struct SDL_Surface {
	Uint32 flags;
	SDL_PixelFormat *format; /* not used in sdlite */		
	int w, h;
	Uint16 pitch;
	void *pixels;
	SDL_Rect clip_rect;	
	Uint32 locked;
	int refcount;
	int colorkey; /* transparency */
} SDL_Surface;


#define SDL_SWSURFACE	0x00000000	 
#define SDL_HWSURFACE	0x00000001	 /* not supported in VC-IDE */
#define SDL_ASYNCBLIT	0x00000004	 /* not supported in VC-IDE */
#define SDL_ANYFORMAT	0x10000000	 
#define SDL_HWPALETTE	0x20000000	 /* not supported in VC-IDE */
#define SDL_DOUBLEBUF	0x40000000	 
#define SDL_FULLSCREEN	0x80000000	 /* not supported in VC-IDE */
#define SDL_OPENGL      0x00000002   /* not supported in VC-IDE */
#define SDL_OPENGLBLIT	0x0000000A	 /* not supported in VC-IDE */
#define SDL_RESIZABLE	0x00000010	 /* not supported in VC-IDE */
#define SDL_NOFRAME	    0x00000020	 /* not supported in VC-IDE */

#define SDL_SRCCOLORKEY	0x00001000	
#define SDL_RLEACCEL	0x00004000	 /* not supported in VC-IDE */


/* note: currently only bpp=32 is supported */
extern FUNC_IMPORT SDL_Surface* SDL_SetVideoMode(int width, int height, int bpp, Uint32 flags);

extern FUNC_IMPORT SDL_Surface* SDL_GetVideoSurface(void);
extern FUNC_IMPORT void SDL_FreeSurface(SDL_Surface *surface);
/* note: currently only bmps with bpp=24 are supported */
extern FUNC_IMPORT SDL_Surface* SDL_LoadBMP(char* src);
extern FUNC_IMPORT int  SDL_SetColorKey(SDL_Surface *surface, Uint32 flag, Uint32 key);

extern FUNC_IMPORT int SDL_FillRect(SDL_Surface *dst, SDL_Rect *dstrect, Uint32 color);



#define SDL_BlitSurface SDL_UpperBlit
extern FUNC_IMPORT int SDL_UpperBlit
			(SDL_Surface *src, SDL_Rect *srcrect,
			 SDL_Surface *dst, SDL_Rect *dstrect);

extern FUNC_IMPORT int SDL_Flip(SDL_Surface *src);
extern FUNC_IMPORT int SDL_LockSurface(SDL_Surface *src);
extern FUNC_IMPORT void SDL_UnlockSurface(SDL_Surface *src);

/* Keyboard ******************************************************************/
typedef enum {
        
	SDLK_UNKNOWN		= 0,
	SDLK_FIRST		= 0,
	SDLK_BACKSPACE		= 8,
	SDLK_TAB		= 9,
	SDLK_CLEAR		= 12,
	SDLK_RETURN		= 13,
	SDLK_PAUSE		= 19,
	SDLK_ESCAPE		= 27,
	SDLK_SPACE		= 32,
	SDLK_EXCLAIM		= 33,
	SDLK_QUOTEDBL		= 34,
	SDLK_HASH		= 35,
	SDLK_DOLLAR		= 36,
	SDLK_AMPERSAND		= 38,
	SDLK_QUOTE		= 39,
	SDLK_LEFTPAREN		= 40,
	SDLK_RIGHTPAREN		= 41,
	SDLK_ASTERISK		= 42,
	SDLK_PLUS		= 43,
	SDLK_COMMA		= 44,
	SDLK_MINUS		= 45,
	SDLK_PERIOD		= 46,
	SDLK_SLASH		= 47,
	SDLK_0			= 48,
	SDLK_1			= 49,
	SDLK_2			= 50,
	SDLK_3			= 51,
	SDLK_4			= 52,
	SDLK_5			= 53,
	SDLK_6			= 54,
	SDLK_7			= 55,
	SDLK_8			= 56,
	SDLK_9			= 57,
	SDLK_COLON		= 58,
	SDLK_SEMICOLON		= 59,
	SDLK_LESS		= 60,
	SDLK_EQUALS		= 61,
	SDLK_GREATER		= 62,
	SDLK_QUESTION		= 63,
	SDLK_AT			= 64,
	SDLK_LEFTBRACKET	= 91,
	SDLK_BACKSLASH		= 92,
	SDLK_RIGHTBRACKET	= 93,
	SDLK_CARET		= 94,
	SDLK_UNDERSCORE		= 95,
	SDLK_BACKQUOTE		= 96,
	SDLK_a			= 97,
	SDLK_b			= 98,
	SDLK_c			= 99,
	SDLK_d			= 100,
	SDLK_e			= 101,
	SDLK_f			= 102,
	SDLK_g			= 103,
	SDLK_h			= 104,
	SDLK_i			= 105,
	SDLK_j			= 106,
	SDLK_k			= 107,
	SDLK_l			= 108,
	SDLK_m			= 109,
	SDLK_n			= 110,
	SDLK_o			= 111,
	SDLK_p			= 112,
	SDLK_q			= 113,
	SDLK_r			= 114,
	SDLK_s			= 115,
	SDLK_t			= 116,
	SDLK_u			= 117,
	SDLK_v			= 118,
	SDLK_w			= 119,
	SDLK_x			= 120,
	SDLK_y			= 121,
	SDLK_z			= 122,
	SDLK_DELETE		= 127,
	SDLK_KP0		= 256,
	SDLK_KP1		= 257,
	SDLK_KP2		= 258,
	SDLK_KP3		= 259,
	SDLK_KP4		= 260,
	SDLK_KP5		= 261,
	SDLK_KP6		= 262,
	SDLK_KP7		= 263,
	SDLK_KP8		= 264,
	SDLK_KP9		= 265,
	SDLK_KP_PERIOD		= 266,
	SDLK_KP_DIVIDE		= 267,
	SDLK_KP_MULTIPLY	= 268,
	SDLK_KP_MINUS		= 269,
	SDLK_KP_PLUS		= 270,
	SDLK_KP_ENTER		= 271,
	SDLK_KP_EQUALS		= 272,
	SDLK_UP			= 273,
	SDLK_DOWN		= 274,
	SDLK_RIGHT		= 275,
	SDLK_LEFT		= 276,
	SDLK_INSERT		= 277,
	SDLK_HOME		= 278,
	SDLK_END		= 279,
	SDLK_PAGEUP		= 280,
	SDLK_PAGEDOWN		= 281,
	SDLK_F1			= 282,
	SDLK_F2			= 283,
	SDLK_F3			= 284,
	SDLK_F4			= 285,
	SDLK_F5			= 286,
	SDLK_F6			= 287,
	SDLK_F7			= 288,
	SDLK_F8			= 289,
	SDLK_F9			= 290,
	SDLK_F10		= 291,
	SDLK_F11		= 292,
	SDLK_F12		= 293,
	SDLK_F13		= 294,
	SDLK_F14		= 295,
	SDLK_F15		= 296,
	SDLK_NUMLOCK		= 300,
	SDLK_CAPSLOCK		= 301,
	SDLK_SCROLLOCK		= 302,
	SDLK_RSHIFT		= 303,
	SDLK_LSHIFT		= 304,
	SDLK_RCTRL		= 305,
	SDLK_LCTRL		= 306,
	SDLK_RALT		= 307,
	SDLK_LALT		= 308,
	SDLK_RMETA		= 309,
	SDLK_LMETA		= 310,
	SDLK_LSUPER		= 311,		 
	SDLK_RSUPER		= 312,		 
	SDLK_MODE		= 313,		 
	SDLK_COMPOSE		= 314,	
	SDLK_HELP		= 315,
	SDLK_PRINT		= 316,
	SDLK_SYSREQ		= 317,
	SDLK_BREAK		= 318,
	SDLK_MENU		= 319,
	SDLK_POWER		= 320,		 
	SDLK_EURO		= 321,		 
	SDLK_UNDO		= 322,		
	SDLK_LAST
} SDLKey;

typedef enum {
	KMOD_NONE  = 0x0000,
	KMOD_LSHIFT= 0x0001,
	KMOD_RSHIFT= 0x0002,
	KMOD_LCTRL = 0x0040,
	KMOD_RCTRL = 0x0080,
	KMOD_LALT  = 0x0100,
	KMOD_RALT  = 0x0200,
	KMOD_LMETA = 0x0400,
	KMOD_RMETA = 0x0800,
	KMOD_NUM   = 0x1000,
	KMOD_CAPS  = 0x2000,
	KMOD_MODE  = 0x4000,
	KMOD_RESERVED = 0x8000
} SDLMod;

/* SDL Events  ***************************************************************/

#define SDL_RELEASED    0
#define SDL_PRESSED	    1

typedef enum {
       SDL_NOEVENT = 0,			 
       SDL_ACTIVEEVENT,			 
       SDL_KEYDOWN,			 
       SDL_KEYUP,			 
       SDL_MOUSEMOTION,			 
       SDL_MOUSEBUTTONDOWN,		 
       SDL_MOUSEBUTTONUP,		 
       SDL_JOYAXISMOTION,		/* not supported in VC-IDE */
       SDL_JOYBALLMOTION,		/* not supported in VC-IDE */
       SDL_JOYHATMOTION,		/* not supported in VC-IDE */
       SDL_JOYBUTTONDOWN,		/* not supported in VC-IDE */
       SDL_JOYBUTTONUP,			/* not supported in VC-IDE */
       SDL_QUIT,			 
       SDL_SYSWMEVENT,			/* not supported in VC-IDE */ 
       SDL_EVENT_RESERVEDA,		 
       SDL_EVENT_RESERVEDB,		 
       SDL_VIDEORESIZE,			/* not supported in VC-IDE */
       SDL_VIDEOEXPOSE,			/* not supported in VC-IDE */
       SDL_USEREVENT = 24,
       SDL_NUMEVENTS = 32
} SDL_EventType;

typedef struct SDL_ActiveEvent {
	Uint8 type;	 
	Uint8 gain;	 
	Uint8 state;	 
} SDL_ActiveEvent;

typedef struct SDL_keysym {
	Uint8 scancode;			 
	SDLKey sym;			 
	SDLMod mod;			 
	Uint16 unicode;			 
} SDL_keysym;

typedef struct SDL_KeyboardEvent {
	Uint8 type;	 
	Uint8 state;	 
	SDL_keysym keysym;
} SDL_KeyboardEvent;

typedef struct SDL_MouseMotionEvent {
	Uint8 type;	 
	Uint8 state;	 
	Uint16 x, y;	 
	Sint16 xrel;	 
	Sint16 yrel;	
} SDL_MouseMotionEvent;

#define SDL_BUTTON_LEFT 1
#define SDL_BUTTON_RIGHT 2


typedef struct SDL_MouseButtonEvent {
	Uint8 type;	  
	Uint8 button;	 
	Uint8 state;	 
	Uint16 x, y;
} SDL_MouseButtonEvent;

typedef struct SDL_QuitEvent {
	Uint8 type;	
} SDL_QuitEvent;

typedef struct SDL_UserEvent {
	Uint8 type;	 
	int code;	 
	void *data1;	 
	void *data2;	 
} SDL_UserEvent;

typedef union SDL_Event {
	Uint8 type;
	SDL_ActiveEvent active;
	SDL_KeyboardEvent key;
	SDL_MouseMotionEvent motion;
	SDL_MouseButtonEvent button;
	SDL_QuitEvent quit;
	SDL_UserEvent user;
} SDL_Event;

extern FUNC_IMPORT int SDL_WaitEvent(SDL_Event *event);

extern FUNC_IMPORT int SDL_PollEvent(SDL_Event *event);

extern FUNC_IMPORT int SDL_PumpEvents(void);



/* Audio ******************************************************************/

#define AUDIO_U8	    0x0008	
#define AUDIO_S8	    0x8008	
#define AUDIO_U16LSB	0x0010	
#define AUDIO_S16LSB	0x8010	
#define AUDIO_U16MSB	0x1010	
#define AUDIO_S16MSB	0x9010
#define AUDIO_U16	AUDIO_U16LSB
#define AUDIO_S16	AUDIO_S16LSB
#define AUDIO_U16SYS	AUDIO_U16LSB
#define AUDIO_S16SYS	AUDIO_S16LSB

typedef struct SDL_AudioSpec {
	int freq;		
	Uint16 format;	
	Uint8  channels;
	Uint8  silence;	
	Uint16 samples;	
	Uint16 padding;	
	Uint32 size;
	void (*callback)(void *userdata, Uint8 *stream, int len);
	void  *userdata;
} SDL_AudioSpec;

extern FUNC_IMPORT int  SDL_OpenAudio(SDL_AudioSpec *desired, SDL_AudioSpec *obtained);

extern FUNC_IMPORT void SDL_PauseAudio(int pause_on);

extern FUNC_IMPORT SDL_AudioSpec *SDL_LoadWAV(char *src, SDL_AudioSpec *spec, Uint8 **audio_buf, Uint32 *audio_len);

extern FUNC_IMPORT void SDL_FreeWAV(Uint8 *audio_buf);

#define SDL_MIX_MAXVOLUME 128

extern FUNC_IMPORT void SDL_MixAudio(Uint8 *dst, const Uint8 *src, Uint32 len, int volume);

extern FUNC_IMPORT void SDL_CloseAudio(void);


/* Timer ******************************************************************/

extern FUNC_IMPORT void SDL_Delay(Uint32 ms);

typedef Uint32 SDL_TimerID;
typedef int SDL_bool;
typedef Uint32 (*SDL_NewTimerCallback)(Uint32 interval, void *param);

extern FUNC_IMPORT SDL_TimerID SDL_AddTimer(Uint32 interval, SDL_NewTimerCallback callback, void *param);
extern FUNC_IMPORT SDL_bool SDL_RemoveTimer(SDL_TimerID id);



/* Error ******************************************************************/
extern FUNC_IMPORT char * SDL_GetError(void);

extern FUNC_IMPORT void SDL_WM_SetCaption(const char *title, const char *icon);

#endif // SDLITE_H