#ifndef _errno_h
#define _errno_h
/***************************************************************************
	SimpleC - A Simple C code generator
    (c) 2008 by Dieter R. Pawelczak 

 ****************************************************************************

 Header File errno.h - as defined in C11 section 7.5

 ****************************************************************************/
extern int errno;

#define ERANGE 0x10000
#define EILSEQ 0x10001
#define EDOM   0x10002

/* implementation specific */

#define ERR_NULL          0x50000
#define ERR_NO_STREAM     0x50001
#define ERR_SEEK_OUTSIDE  0x50002

#endif /* _errno_h */