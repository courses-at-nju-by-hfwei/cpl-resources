#ifndef _stddef_h
#define _stddef_h
/***************************************************************************
	SimpleC - A Simple C Compiler
    (c) 2008-2011 by Dieter R. Pawelczak 

 ****************************************************************************
 
  Header File stddef.h - as defined in C11 section 7.19
 ****************************************************************************/


#ifdef __STDC_VERSION__
#if __STDC_VERSION__ < 199901L
#define restrict
#define _Noreturn
#else
    typedef unsigned long rsize_t;
#endif
#endif

#ifndef NULL
#define NULL (void*) 0
#endif

typedef unsigned long size_t;
typedef size_t rsize_t;
typedef unsigned long ptrdiff_t;
typedef unsigned long time_t;
/* typedef struct { long lo,hi; } time_t; /* 64 Bit time */

#define offsetof(type, designator) ((char*)(&(type.designator)))-((char*) &(type)) 
#define max_align_t  unsigned long
#undef wchar_t

#define wchar_t unsigned char /* wchar_t is not yet supported */
#endif