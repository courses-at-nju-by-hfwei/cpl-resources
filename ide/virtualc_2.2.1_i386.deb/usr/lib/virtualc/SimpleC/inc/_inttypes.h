
#ifndef _inttypes_h
#define _inttypes_h


/**************************************************************************
 SimpleC - A Simple C code generator
 (c) 2008 by Dieter R. Pawelczak
 
 ****************************************************************************
 
 Header File inttypes - as defined in C11 Section 7.8.2
 
 ****************************************************************************/
#include <stdint.h>
#include <stddef.h>


typedef struct { intmax_t div, rem; } imaxdiv_t;

/* format specifies for printf() - int types */
#define PRId8  "hhd"
#define PRId16 "hd"
#define PRId32 "d"
#define PRIdLEAST8  "hhd"
#define PRIdLEAST16 "hd"
#define PRIdLEAST32 "d"
#define PRIdFAST8   "hhd"
#define PRIdFAST16  "hd"
#define PRIdFAST32  "d"
#define PRIdMAX     "ld"
#define PRIdPTR     "d"
#define PRIi8  "hhi"
#define PRIi16 "hi"
#define PRIi32 "i"
#define PRIiLEAST8  "hhi"
#define PRIiLEAST16 "hi"
#define PRIiLEAST32 "i"
#define PRIiFAST8   "hid"
#define PRIiFAST16  "hi"
#define PRIiFAST32  "i"
#define PRIiMAX     "li"
#define PRIiPTR     "i"
#define PRIo8  "hho"
#define PRIo16 "ho"
#define PRIo32 "o"
#define PRIoLEAST8  "hho"
#define PRIoLEAST16 "ho"
#define PRIoLEAST32 "o"
#define PRIoFAST8   "hho"
#define PRIoFAST16  "ho"
#define PRIoFAST32  "o"
#define PRIoMAX     "lo"
#define PRIoPTR     "o"
#define PRIu8  "hhu"
#define PRIu16 "hu"
#define PRIu32 "u"
#define PRIuLEAST8  "hhu"
#define PRIuLEAST16 "hu"
#define PRIuLEAST32 "u"
#define PRIuFAST8   "hhu"
#define PRIuFAST16  "hu"
#define PRIuFAST32  "u"
#define PRIuMAX     "lu"
#define PRIuPTR     "u"
#define PRIx8  "hhx"
#define PRIx16 "hx"
#define PRIx32 "x"
#define PRIxLEAST8  "hhx"
#define PRIxLEAST16 "hx"
#define PRIxLEAST32 "x"
#define PRIxFAST8   "hhx"
#define PRIxFAST16  "hx"
#define PRIxFAST32  "x"
#define PRIxMAX     "lx"
#define PRIxPTR     "x"
#define PRIX8  "hhX"
#define PRIX16 "hX"
#define PRIX32 "X"
#define PRIXLEAST8  "hhX"
#define PRIXLEAST16 "hX"
#define PRIXLEAST32 "X"
#define PRIXFAST8   "hhX"
#define PRIXFAST16  "hX"
#define PRIXFAST32  "X"
#define PRIXMAX     "lX"
#define PRIXPTR     "X"
/* format specifiers for scanf() */
#define SCNd8  "hhd"
#define SCNd16 "hd"
#define SCNd32 "d"
#define SCNdLEAST8  "hhd"
#define SCNdLEAST16 "hd"
#define SCNdLEAST32 "d"
#define SCNdFAST8   "hhd"
#define SCNdFAST16  "hd"
#define SCNdFAST32  "d"
#define SCNdMAX     "ld"
#define SCNdPTR     "d"
#define SCNi8  "hhi"
#define SCNi16 "hi"
#define SCNi32 "i"
#define SCNiLEAST8  "hhi"
#define SCNiLEAST16 "hi"
#define SCNiLEAST32 "i"
#define SCNiFAST8   "hid"
#define SCNiFAST16  "hi"
#define SCNiFAST32  "i"
#define SCNiMAX     "li"
#define SCNiPTR     "i"
#define SCNo8  "hho"
#define SCNo16 "ho"
#define SCNo32 "o"
#define SCNoLEAST8  "hho"
#define SCNoLEAST16 "ho"
#define SCNoLEAST32 "o"
#define SCNoFAST8   "hho"
#define SCNoFAST16  "ho"
#define SCNoFAST32  "o"
#define SCNoMAX     "lo"
#define SCNoPTR     "o"
#define SCNu8  "hhu"
#define SCNu16 "hu"
#define SCNu32 "u"
#define SCNuLEAST8  "hhu"
#define SCNuLEAST16 "hu"
#define SCNuLEAST32 "u"
#define SCNuFAST8   "hhu"
#define SCNuFAST16  "hu"
#define SCNuFAST32  "u"
#define SCNuMAX     "lu"
#define SCNuPTR     "u"
#define SCNx8  "hhx"
#define SCNx16 "hx"
#define SCNx32 "x"
#define SCNxLEAST8  "hhx"
#define SCNxLEAST16 "hx"
#define SCNxLEAST32 "x"
#define SCNxFAST8   "hhx"
#define SCNxFAST16  "hx"
#define SCNxFAST32  "x"
#define SCNxMAX     "lx"
#define SCNxPTR     "x"
#define SCNX8  "hhX"
#define SCNX16 "hX"
#define SCNX32 "X"
#define SCNXLEAST8  "hhX"
#define SCNXLEAST16 "hX"
#define SCNXLEAST32 "X"
#define SCNXFAST8   "hhX"
#define SCNXFAST16  "hX"
#define SCNXFAST32  "X"
#define SCNXMAX     "lX"
#define SCNXPTR     "X"

intmax_t imaxabs(intmax_t x);
imaxdiv_t imaxdiv(intmax_t numer, intmax_t denom);
intmax_t strtoimax(const char * restrict nptr,
                   char ** restrict endptr, int base);
uintmax_t strtoumax(const char * restrict nptr,
                    char ** restrict endptr, int base);

intmax_t wcstoimax(const wchar_t * restrict nptr,
                   wchar_t ** restrict endptr, int base);
uintmax_t wcstoumax(const wchar_t * restrict nptr,
                    wchar_t ** restrict endptr, int base);

#endif
