#ifndef _STDARG_H
#define _STDARG_H

/***************************************************************************
	SimpleC - A Simple C compiler - sample tiny C library
    (c) 2010 by Dieter R. Pawelczak 

 ****************************************************************************

 Header File stdarg.h

 ****************************************************************************/

/* va_args types and macros */

#ifdef _MANAGED
#pragma object(va_list,"value class [mscorlib]System.ArgIterator")
#define va_start(argptr,formatstring) asm (arglist); \
asm(newobj instance void [mscorlib]System.ArgIterator::.ctor(valuetype [mscorlib]System.RuntimeArgumentHandle)); \
asm(stloc _##argptr);
#define va_arg(argptr,type) (type) asm {&argptr; \
call instance typedref [mscorlib]System.ArgIterator::GetNextArg(); \
refanyval __GetCILType(type);\
ldind.__GetDataTypeDirective(type);\
	}

#define __GetCILType(type) \
#if typeof(type)==typeof(double) #pragma inject "\n" \
float64\
#elif typeof(type)==typeof(float) #pragma inject "\n"\
float32\
#elif typeof(type)==typeof(long) #pragma inject "\n"\
int64\
#elif typeof(type)==typeof(unsigned long) #pragma inject "\n"\
uint64\
#elif typeof(type)==typeof(short) #pragma inject "\n"\
int16\
#elif typeof(type)==typeof(unsigned short) #pragma inject "\n"\
uint16\
#elif typeof(type)==typeof(char) #pragma inject "\n"\
int8\
#elif typeof(type)==typeof(unsigned char) #pragma inject "\n"\
uint8\
#elif typeof(type)==typeof(char*) #pragma inject "\n"\
int8* \
#elif typeof(type)==typeof(short*) #pragma inject "\n"\
int16* \
#elif typeof(type)==typeof(int*) #pragma inject "\n"\
int32* \
#elif typeof(type)==typeof(double*) #pragma inject "\n"\
float64* \
#elif typeof(type)==typeof(float*) #pragma inject "\n"\
float32* \
#else\
int32\
#endif

#define __GetDataTypeDirective(type) \
#if typeof(type)==typeof(double) #pragma inject "\n" \
r8 \
#elif typeof(type)==typeof(float) #pragma inject "\n" \
r4 \
#elif typeof(type)==typeof(long) #pragma inject "\n" \
i8 \
#elif typeof(type)==typeof(unsigned long) #pragma inject "\n" \
u8 \
#elif typeof(type)==typeof(short) #pragma inject "\n" \
i2 \
#elif typeof(type)==typeof(unsigned short) #pragma inject "\n" \
u2 \
#elif typeof(type)==typeof(char) #pragma inject "\n" \
i1 \
#elif typeof(type)==typeof(unsigned char) #pragma inject "\n" \
u1 \
#else \
i4 \
#endif

#else

  typedef int* va_list;
  #define _INT_SIZE(x) ((sizeof(x)+sizeof(int)-1)/sizeof(int)) 
  #define va_start(argptr,formatstring) argptr=(((int*)(&formatstring))+_INT_SIZE(formatstring)) 
  #define va_arg(argptr,type) \
		*(type*)(((int*)(argptr+=_INT_SIZE(type)))-_INT_SIZE(type))

#endif

#define va_end(argptr) 
#define va_copy(dest, src) dest=src;

#include <stdio.h>

int vsscanf(char* str, const char* format, va_list argptr);
int vsscanf_s(char* str, const char* format, va_list argptr);
int vsprintf(char* str, const char* format, va_list argptr);
int vsnprintf(char* restrict str, size_t n, const char* restrict format, va_list argptr);

int vfscanf(FILE*stream, const char* format, va_list argptr);
int vfscanf_s(FILE*stream, const char* format, va_list argptr);
int vfprintf(FILE*stream, const char* format, va_list argptr);
int vprintf(const char* format, va_list argptr);


#endif