#ifndef _TSC_H
#define _TSC_H
#include <mopvmex.h>
#include <string.h>
/***************************************************************************
 TSC - A Test Suite Compiler for the MOPVM
 (c) 2008-2016 by Dieter R. Pawelczak
 
 ****************************************************************************
 
 Header File tsc.h - defines the macros for the TSC
 ****************************************************************************/

/* supported POSIX function */
extern char* strcasecmp(const char* a, const char* b);

#define DEFAULT_LIMIT 1000000
#define DEFAULT_SIZE 512
#define _ToSTRING(x) #x

#define FUT(x) _fut = _ToSTRING(x), _result = (long double) (x)

/* asserts and expects */

#define ASSERT_RANGE(x,from,to) \
{  double _result = (double) x; \
   if (_result < from || _result > to) \
    FATAL("(%s) is not in range from: %f to %f, result is: %f", _ToSTRING(x), (double) from, (double) to, _result) \
}
#define ASSERT_EPSILON(x,y,epsilon) \
{  double _result = (double) x; \
if (fabs(_result - (y)) > epsilon) \
FATAL("for (%s) is expected: %f [+/- %f], but result is: %f", _ToSTRING(x), (double) y, epsilon, _result) \
}
#define EXPECT_RANGE(x,from,to) \
{  double _result = (double) x; \
if (_result < from || _result > to) \
ERROR("(%s) is not in range from: %f to %f, result is: %f", _ToSTRING(x), (double) from, (double) to, _result); \
}
#define EXPECT_EPSILON(x,y,epsilon) \
{  double _result = (double) x; \
if (fabs(_result - (y)) > epsilon) \
ERROR("for (%s) is expected: %f [+/- %f], but result is: %f", _ToSTRING(x), (double) y, epsilon, _result); \
}
#define ASSERT_STREQ(x,y) \
{  char* _result = (char*) x; \
    if (_result != y) \
    { \
    int _diff = -128; \
    if (_result && (y)) \
        _diff = strcmp(_result,y); \
    if (_diff) {\
        if (y) {\
            FATAL("for string expression (%s) content (\"%s\") is expected, but result is: \"%s\"<br>[diff: %d]", _ToSTRING(x), (char*) y,  _result, _diff)  \
            }else FATAL("for string expression (%s) is NULL expected, but result is: \"%s\"", _ToSTRING(x),  _result) } \
    }\
}

#define ASSERT_STRCASEEQ(x,y) \
{  char* _result = (char*) x; \
if (_result != y) \
{ \
int _diff = -128; \
if (_result && (y)) \
_diff = strcasecmp(_result,y); \
if (_diff) {\
if (y) {\
FATAL("for string expression (%s) content (\"%s\") is expected, but result is: \"%s\"<br>[diff: %d]", _ToSTRING(x), (char*) y,  _result, _diff)  \
}else FATAL("for string expression (%s) is NULL expected, but result is: \"%s\"", _ToSTRING(x),  _result) } \
}\
}

#define ASSERT_STRNE(x,y) \
{  char* _result = (char*) x; \
int _diff = -128; \
if (_result == (y))  _diff = 0; \
if (_result && (y)) \
_diff = strcmp(_result,y); \
if (_diff == 0) \
    if (y) \
        FATAL("for string expression (%s) content should differ from: (\"%s\"), but result is: \"%s\"", \
    _ToSTRING(x), (char*) y,  _result)  \
    else \
FATAL("for string expression (%s) a valid string is expected, but result is: NULL", \
      _ToSTRING(x))  \
}

#define ASSERT_STRCASENE(x,y) \
{  char* _result = (char*) x; \
int _diff = -128; \
if (_result == (y))  _diff = 0; \
if (_result && (y)) \
_diff = strcasecmp(_result,y); \
if (_diff == 0) \
if (y) \
FATAL("for string expression (%s) content should differ from: (\"%s\"), but result is: \"%s\"", \
_ToSTRING(x), (char*) y,  _result)  \
else \
FATAL("for string expression (%s) a valid string is expected, but result is: NULL", \
_ToSTRING(x))  \
}

#define EXPECT_STREQ(x,y) \
{  char* _result = (char*) x; \
if (_result != y) \
{ \
int _diff = -128; \
if (_result && (y)) \
_diff = strcmp(_result,y); \
if (_diff) {\
if (y) {\
ERROR("for string expression (%s) content (\"%s\") is expected, but result is: \"%s\"<br>[diff: %d]", _ToSTRING(x), (char*) y,  _result, _diff);  \
}else ERROR("for string expression (%s) is NULL expected, but result is: \"%s\"", _ToSTRING(x),  _result); } \
}\
}

#define EXPECT_STRCASEEQ(x,y) \
{  char* _result = (char*) x; \
if (_result != y) \
{ \
int _diff = -128; \
if (_result && (y)) \
_diff = strcasecmp(_result,y); \
if (_diff) {\
if (y) {\
ERROR("for string expression (%s) content (\"%s\") is expected, but result is: \"%s\"<br>[diff: %d]", _ToSTRING(x), (char*) y,  _result, _diff);  \
}else ERROR("for string expression (%s) is NULL expected, but result is: \"%s\"", _ToSTRING(x),  _result); } \
}\
}

#define EXPECT_STRNE(x,y) \
{  char* _result = (char*) x; \
int _diff = -128; \
if (_result == (y))  _diff = 0; \
if (_result && (y)) \
_diff = strcmp(_result,y); \
if (_diff == 0) \
if (y) \
ERROR("for string expression (%s) content should differ from: (\"%s\"), but result is: \"%s\"", \
_ToSTRING(x), (char*) y,  _result);  \
else \
ERROR("for string expression (%s) a valid string is expected, but result is: NULL", \
_ToSTRING(x));  \
}

#define EXPECT_STRCASENE(x,y) \
{  char* _result = (char*) x; \
int _diff = -128; \
if (_result == (y))  _diff = 0; \
if (_result && (y)) \
_diff = strcasecmp(_result,y); \
if (_diff == 0) \
if (y) \
ERROR("for string expression (%s) content should differ from: (\"%s\"), but result is: \"%s\"", \
_ToSTRING(x), (char*) y,  _result);  \
else \
ERROR("for string expression (%s) a valid string is expected, but result is: NULL", \
_ToSTRING(x));  \
}


#define MESSAGE(XXXX, ASSERT_STRING, x, y, xop) _Generic((x), \
float:  XXXX(ASSERT_STRING "%lg", _ToSTRING((x)), _ToSTRING((y)), xop), \
double:  XXXX(ASSERT_STRING "%lg", _ToSTRING((x)), _ToSTRING((y)), xop), \
long double:  XXXX(ASSERT_STRING "%lg", _ToSTRING((x)), _ToSTRING((y)), xop), \
char:  XXXX(ASSERT_STRING "%hhd", _ToSTRING((x)), _ToSTRING((y)), (char) xop), \
signed char:  XXXX(ASSERT_STRING "%hhd", _ToSTRING((x)), _ToSTRING((y)), (char) xop), \
unsigned char:  XXXX(ASSERT_STRING "%hhu", _ToSTRING((x)), _ToSTRING((y)), (unsigned char) xop), \
short:  XXXX(ASSERT_STRING "%hd", _ToSTRING((x)), _ToSTRING((y)), (short) xop), \
signed short:  XXXX(ASSERT_STRING "%hd", _ToSTRING((x)), _ToSTRING((y)), (short) xop), \
unsigned short:  XXXX(ASSERT_STRING "%hu", _ToSTRING((x)), _ToSTRING((y)), (unsigned short) xop), \
int:  XXXX(ASSERT_STRING "%d", _ToSTRING((x)), _ToSTRING((y)), (int) xop), \
signed int:  XXXX(ASSERT_STRING "%d", _ToSTRING((x)), _ToSTRING((y)), (int) xop), \
unsigned int:  XXXX(ASSERT_STRING "%u", _ToSTRING((x)), _ToSTRING((y)), (unsigned int) xop), \
long:  XXXX(ASSERT_STRING "%ld", _ToSTRING((x)), _ToSTRING((y)), (long) xop), \
signed long:  XXXX(ASSERT_STRING "%ld", _ToSTRING((x)), _ToSTRING((y)), (long) xop), \
unsigned long:  XXXX(ASSERT_STRING "%lu", _ToSTRING((x)), _ToSTRING((y)), (unsigned long) xop), \
long long:  XXXX(ASSERT_STRING "%ld", _ToSTRING((x)), _ToSTRING((y)), (long long) xop), \
signed long long:  XXXX(ASSERT_STRING "%ld", _ToSTRING((x)), _ToSTRING((y)), (long long) xop), \
unsigned long long:  XXXX(ASSERT_STRING "%lu", _ToSTRING((x)), _ToSTRING((y)), (unsigned long long) xop), \
default: XXXX(ASSERT_STRING "%p", _ToSTRING((x)), _ToSTRING((y)), (void*)(unsigned int) xop))

#define CAST_IF_PTR(x) (_Generic((x), char:(x), unsigned char: (x), signed char: (x),\
int:(x), unsigned int: (x), signed int: (x),\
long:(x), unsigned long: (x), signed long: (x),\
short:(x), unsigned short: (x), signed short: (x),\
float:(x), double: (x), long double: (x),\
long long:(x), unsigned long long: (x), signed long long: (x),\
default: (unsigned int) (x)))

#define ASSERT_TRUE(x) { \
unsigned int _xop = (unsigned int)(x); \
if(!_xop) { MESSAGE(_printFatalToOutputArgs, "%s should be %s, but result is false: ", x, true,  _xop); return; } \
}
#define ASSERT_FALSE(x) { \
unsigned int _xop = (unsigned int)(x); \
if(_xop) { MESSAGE(_printFatalToOutputArgs, "%s should be %s, but result is true: ", x, false,  _xop); return; } \
}
#define EXPECT_TRUE(x) { \
unsigned int _xop = (unsigned int)(x); \
if(!_xop) { MESSAGE(_printErrorToOutputArgs, "%s should be %s, but result is false: ", x, true,  _xop); } \
}
#define EXPECT_FALSE(x) { \
unsigned int _xop = (unsigned int)(x); \
if(_xop) { MESSAGE(_printErrorToOutputArgs, "%s should be %s, but result is true: ", x, false,  _xop);  } \
}

#define ASSERT_EQ(x,y) { \
    long double _xop = CAST_IF_PTR(x); \
    if (_xop != CAST_IF_PTR(y)){MESSAGE(_printFatalToOutputArgs, "%s should be equal to: %s, but result is: ", x, y, _xop); return; } \
  }
#define EXPECT_EQ(x,y) { \
long double _xop = (long double)(x); \
if (_xop != (long double)(y))MESSAGE(_printErrorToOutputArgs, "%s should be equal to: %s, but result is: ", x, y, _xop); \
}
#define ASSERT_NE(x,y) { \
long double _xop = CAST_IF_PTR(x); \
if (_xop == CAST_IF_PTR(y)){MESSAGE(_printFatalToOutputArgs, "%s should not be equal to: %s, but result is: ", x, y, _xop); return; } \
}
#define EXPECT_NE(x,y) { \
long double _xop = CAST_IF_PTR(x); \
if (_xop == CAST_IF_PTR(y))MESSAGE(_printErrorToOutputArgs, "%s should not be equal to: %s, but result is: ", x, y, _xop); \
}

#define ASSERT_LE(x,y) { \
long double _xop = CAST_IF_PTR(x); \
if (_xop > CAST_IF_PTR(y)){MESSAGE(_printFatalToOutputArgs, "%s should be less or equal to: %s, but result is: ", x, y, _xop); return; } \
}
#define EXPECT_LE(x,y) { \
long double _xop = CAST_IF_PTR(x); \
if (_xop > CAST_IF_PTR(y))MESSAGE(_printErrorToOutputArgs, "%s should be less or equal to: %s, but result is: ", x, y, _xop); \
}
#define ASSERT_LT(x,y) { \
long double _xop = CAST_IF_PTR(x); \
if (_xop >= CAST_IF_PTR(y)){MESSAGE(_printFatalToOutputArgs, "%s should be less than: %s, but result is: ", x, y, _xop); return; } \
}
#define EXPECT_LT(x,y) { \
long double _xop = CAST_IF_PTR(x); \
if (_xop >= CAST_IF_PTR(y))MESSAGE(_printErrorToOutputArgs, "%s should be less than: %s, but result is: ", x, y, _xop); \
}

#define ASSERT_GE(x,y) { \
long double _xop = CAST_IF_PTR(x); \
if (_xop < CAST_IF_PTR(y)){MESSAGE(_printFatalToOutputArgs, "%s should be greater or equal to: %s, but result is: ", x, y, _xop); return; } \
}
#define EXPECT_GE(x,y) { \
long double _xop = CAST_IF_PTR(x); \
if (_xop < CAST_IF_PTR(y))MESSAGE(_printErrorToOutputArgs, "%s should be greater or equal to: %s, but result is: ", x, y, _xop); \
}
#define ASSERT_GT(x,y) { \
long double _xop = CAST_IF_PTR(x); \
if (_xop <= CAST_IF_PTR(y)){MESSAGE(_printFatalToOutputArgs, "%s should be greater than: %s, but result is: ", x, y, _xop); return; } \
}
#define EXPECT_GT(x,y) { \
long double _xop = CAST_IF_PTR(x); \
if (_xop <= CAST_IF_PTR(y))MESSAGE(_printErrorToOutputArgs, "%s should be greater than: %s, but result is: ", x, y, _xop); \
}

#define _genericCompareOperands(x,y) 1*_Generic((x), \
char* : (strcmp(x,y) == 0), \
unsigned char* : (strcmp(x,y) == 0), \
long:   (x == y), \
char:   (x == y), \
float:  (x == y), \
double: (x == y), \
long double: (x == y),\
void* : (x == y), \
int* : (x != 0 && y != 0 && *x == *y), \
short* : (x != 0 && y != 0 && *x == *y), \
long* : (x != 0 && y != 0 && *x == *y), \
unsigned long* : (x != 0 && y != 0 && *x == *y), \
unsigned int* : (x != 0 && y != 0 && *x == *y), \
unsigned short* : (x != 0 && y != 0 && *x == *y), \
unsigned int: (x == y), \
unsigned long: (x==y), \
unsigned short: (x==y), \
unsigned char: (x==y), \
int: (x==y), \
default: (memcmp(x,y, sizeof(x)) ==0))

/* short cuts */
#define FATAL(...) { _printFatalToOutputArgs(__VA_ARGS__); return; }
#define ERROR(...) _printErrorToOutputArgs(__VA_ARGS__)
#define WARN(x) _printWarningToOutputArgs(__VA_ARGS__)
#define PRINT(x) _printStringToOutputArgs(__VA_ARGS__)

#define IsInFUT() (__gIsInFut)

#endif
