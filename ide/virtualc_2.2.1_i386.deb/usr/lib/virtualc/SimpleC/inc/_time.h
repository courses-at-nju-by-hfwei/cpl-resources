#ifndef _TIME_H
#define _TIME_H
#include <stddef.h>

typedef size_t clock_t;
typedef size_t time_t; /*ToDo: make 64 Bit */

#ifdef _M_IX86
/* processor specific, as clock_t queries processor clock */
#define CLOCKS_PER_SEC  5 
#elif defined(_MANANGED)
/* ToDo: define correct */
#define CLOCKS_PER_SEC  1000 
#else
#define CLOCKS_PER_SEC  30000
#endif

typedef unsigned long time_t;

struct tm
{
	int tm_sec;   /* seconds after the minute � [0, 60] */
	int tm_min;   /* minutes after the hour � [0, 59]   */
	int tm_hour;  /* hours since midnight � [0, 23]     */
	int tm_mday;  /* day of the month � [1, 31]         */
	int tm_mon;   /* months since January � [0, 11]     */
	int tm_year;  /* years since 1900                   */
	int tm_wday;  /* days since Sunday � [0, 6]         */
	int tm_yday;  /* days since January 1 � [0, 365]    */
	int tm_isdst; /* Daylight Saving Time flag          */
};

struct timespec {
    time_t tv_sec; /* whole seconds */
    long tv_nsec;  /* nanoseconds */
};

clock_t clock(void); /* returns the processor ticks used for the process */

time_t time(time_t* result); /* seconds from 1970-01-01 */
char* ctime(time_t* time);    /* standard time & date string */
struct tm *localtime(const time_t *timer);
char *asctime(const struct tm *timeptr);

#endif