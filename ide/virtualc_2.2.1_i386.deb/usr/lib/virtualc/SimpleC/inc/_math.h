#ifndef _math_h
#define _math_h

/***************************************************************************
	SimpleC - A Simple C code generator
    (c) 2008 - 2015 by Dieter R. Pawelczak

 ****************************************************************************

 Header File math.h

 ****************************************************************************/

#ifdef _M_IX86
#define _callconv __fast
#else
#define _callconv
#endif

double _callconv sin(double x);
double _callconv cos(double x);
double _callconv fabs(double x);
double _callconv fmod(double a,double b);
double _callconv sqrt(double x);
double _callconv log2(double x);
double _callconv log(double x);
double _callconv log10(double x);
double _callconv pow(double x,double y);
double _callconv floor(double x);
double _callconv ceil(double x);

double acos(double x);
float acosf(float x);
#define acosl acos /* long double version is here equal to double */
double asin(double x);
float asinf(float x);
#define asinl asin /* long double version is here equal to double */
double atan(double x);
float atanf(float x);
#define atanl atan /* long double version is here equal to double */
double atan2(double y, double x);
float atan2f(float y, float x);
#define atan2l atan2 /* long double version is here equal to double */
double cosh(double x);
float coshf(float x);
#define coshl cosh /* long double version is here equal to double */
double sinh(double x);
float sinhf(float x);
#define sinhl sinh /* long double version is here equal to double */
double tanh(double x);
float tanhf(float x);
#define tanhl tanh /* long double version is here equal to double */
double exp(double x);
float expf(float x);
#define expl exp /* long double version is here equal to double */
double frexp(double value, int *exp);
float frexpf(float value, int *exp);
#define frexpl frexp /* long double version is here equal to double */
double ldexp(double x, int exp);
float ldexpf(float x, int exp);
#define ldexpl ldexp /* long double version is here equal to double */
float logf(float x);
#define logl log /* long double version is here equal to double */
float log10f(float x);
#define log10l log10 /* long double version is here equal to double */
float log2f(float x);
#define log2l log2 /* long double version is here equal to double */
double modf(double value, double *iptr);
float modff(float value, float *iptr);
#define modfl modf /* long double version is here equal to double */



float fabsf(float x);
#define fabsl fabs /* long double version is here equal to double */

double hypot(double x, double y);
float hypotf(float x, float y);
#define hypotl hypot /* long double version is here equal to double */

double pow(double x, double y);
float powf(float x, float y);
#define powl pow /* long double version is here equal to double */

float sqrtf(float x);
#define sqrtl sqrt /* long double version is here equal to double */


float ceilf(float x);
#define ceill ceil /* long double version is here equal to double */

float floorf(float x);
#define floorl floor /* long double version is here equal to double */


#define FP_NAN          1
#define FP_INFINITE     2
#define FP_ZERO         3
#define FP_NORMAL       4
#define FP_SUBNORMAL    5

#ifdef __STDC_VERSION__

int _fpclassify_dbl(double);
int _fpclassify_flt(float);
int _signbit_dbl(double);
int _signbit_flt(float);

#define isnan(x) (fpclassify(x) == FP_NAN)
#define isinf(x) (fpclassify(x) == FP_INFINITE)

#include <stdlib.h>

#define nan(x) strtod("NAN", NULL)
#define nanf(x) strtof("NAN", NULL)

#if __STDC_VERSION__ >= 201112
#define fpclassify(x) _Generic((x), float: _fpclassify_flt((x)), double: _fpclassify_dbl((x)), default : _fpclassify_flt((float)(x)))
#define signbit(x) _Generic((x), float: _signbit_flt((x)), double: _signbit_dbl((x)), default : _signbit_flt((float)(x)))

#elif __STDC_VERSION__ >= 199901

#define fpclassify(x) ((sizeof (x) == sizeof (float)) ? _fpclassify_flt(x) : _fpclassify_dbl(x))
#define signbit(x) ((sizeof (x) == sizeof (float)) ? _signbit_flt(x) : _signbit_dbl(x))
#endif
#endif


#ifdef __STDC_VERSION__
#if __STDC_VERSION__ >= 199901
double acosh(double x);
float acoshf(float x);
#define acoshl acosh /* long double version is here equal to double */
double asinh(double x);
float asinhf(float x);
#define asinhl asinh /* long double version is here equal to double */
double atanh(double x);
float atanhf(float x);
#define atanhl atanh /* long double version is here equal to double */
double exp2(double x);
float exp2f(float x);
#define exp2l exp2 /* long double version is here equal to double */
double expm1(double x);
float expm1f(float x);
#define expm1l expm1 /* long double version is here equal to double */
int ilogb(double x);
int ilogbf(float x);
#define ilogbl ilogb /* long double version is here equal to double */
double log1p(double x);
float log1pf(float x);
#define log1pl log1p /* long double version is here equal to double */
double logb(double x);
float logbf(float x);
#define logbl logb /* long double version is here equal to double */
double scalbn(double x, int n);
float scalbnf(float x, int n);
#define scalbln scalbn   /* long equals int on MOPVM */
#define scalblnf scalbnf /* long equals int on MOPVM */
double cbrt(double x);
float cbrtf(float x);
#define cbrtl cbrt /* long double version is here equal to double */
double erf(double x);
float erff(float x);
#define erfl erf /* long double version is here equal to double */

double erfc(double x);
float erfcf(float x);
#define erfcl erfc /* long double version is here equal to double */

double lgamma(double x);
float lgammaf(float x);
#define lgammal lgamma /* long double version is here equal to double */

double tgamma(double x);
float tgammaf(float x);
#define tgammal tgamma /* long double version is here equal to double */

double nearbyint(double x);
float nearbyintf(float x);
#define nearbyintl nearbyint /* long double version is here equal to double */

double rint(double x);
float rintf(float x);
#define rintl rint /* long double version is here equal to double */

long int lrint(double x);
long int lrintf(float x);
#define lrintl lrint /* long double version is here equal to double */

double round(double x);
float roundf(float x);
#define roundl round
long int lround(double x);
long int lroundf(float x);
#define lroundl lround
double trunc(double x);
float truncf(float x);
#define truncl trunc
float fmodf(float x, float y);
#define fmodl fmod
double remainder(double x, double y);
float remainderf(float x, float y);
#define remainderl remainder
double remquo(double x, double y, int *quo);
float remquof(float x, float y, int *quo);
#define remquol remquo

#endif
#endif


#ifdef _USE_MATH_DEFINES

#define M_E        2.71828182845904523536
#define M_LOG2E    1.44269504088896340736
#define M_LOG10E   0.434294481903251827651
#define M_LN2      0.693147180559945309417
#define M_LN10     2.30258509299404568402
#define M_PI       3.14159265358979323846
#define M_PI_2     1.57079632679489661923
#define M_PI_4     0.785398163397448309616
#define M_1_PI     0.318309886183790671538
#define M_2_PI     0.636619772367581343076
#define M_2_SQRTPI 1.12837916709551257390
#define M_SQRT2    1.41421356237309504880
#define M_SQRT1_2  0.707106781186547524401


#endif
#endif