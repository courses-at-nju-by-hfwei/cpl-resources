#ifndef _stdio_h
#define _stdio_h

/***************************************************************************
	SimpleC - A Simple C compiler - sample tiny C library
    (c) 2008-2013 by Dieter R. Pawelczak 

 ****************************************************************************

 Header File stdio.h

 ****************************************************************************/

#include <stddef.h>

#define BUFSIZ        4096
#define FOPEN_MAX     32
#define TMP_MAX       25
#define EOF           -1
#define FILENAME_MAX  512
#define L_tmpnam      16
typedef unsigned int fpos_t;


#ifdef WIN32
	typedef void* FILE_ID;
#else
	typedef int FILE_ID;
#endif

typedef enum { _IOFBF, /* fully buffered stream  */
               _IOLBF, /* line bufferes stream   */
			   _IONBF, /* unbuffered stream      */
} _tIoBufferMode;

typedef enum { SEEK_CUR, /* relative seek from current position */
               SEEK_END, /* relative from end                   */
               SEEK_SET  /* absolut position in the file        */
} _tIoFileSeekMode;


/* files are handles in Win32 */
typedef struct
{
	FILE_ID id;           /* file id from operation system      */
	char *buffer;         /* read-write buffer                  */
	int buffer_pos;       /* read-write position in the buffer  */
	int buffer_max;       /* maximum buffer position            */
	size_t buffer_size;   /* allocated buffer size              */
	int isOpenMarker;     /* flag represents the status of the stream (OPEN or EOF) */
	int isOwnBuffer;      /* if flag set, fclose will call free */
	_tIoBufferMode mode;  /* buffer mode                        */
	int isWriteable;      /* open for write                     */
    int absolutePos;      /* absolute file pos for fseek()      */
} FILE;

typedef struct
{
	unsigned int hi_offset;       /* note, this is currently ignored, so files < 4 GB */
	unsigned int lo_offset;
} fpos_t;

int printf(const char* format, ...);
int scanf(const char* format, ...);
int scanf_s(const char* format, ...);

int sprintf(char* str, const char* format, ...);
int sscanf(const char* str, const char* format, ...);
int sscanf_s(const char* str, const char* format, ...);
int snprintf(char* restrict str, size_t n, const char* restrict format, ...);


int fprintf(FILE* file, const char* format, ...);
int fscanf(FILE* file, const char* format, ...);
int fscanf_s(FILE* file, const char* format, ...);

int setvbuf(FILE *restrict stream, char *restrict buf, int mode, size_t size);
#define setbuf(stream, buf) setvbuf(stream, buf, _IOFBF, BUFSIZ)

extern FILE* stdin;
extern FILE* stdout;
extern FILE* stderr;

FILE* fopen(const char* name, const char *mode);
int fflush(FILE* file);
FILE* freopen(const char* name, const char* mode, FILE* file);
FILE *tmpfile(void);
char *tmpnam(char*s);
void fclose(FILE *file);
int puts(const char* str);
#define putc(c,stream) fputc(c,stream)
#define gets(c) \
#error gets() is taken from the C-standard for security reasons

int fputc(int c, FILE *stream);
int fputs(const char* str,FILE *stream);
int putchar(int c);
char* fgets(char* str,int len,FILE* file);
int fgetc(FILE *stream);
#define getc(x) fgetc(x)
int ungetc(int c, FILE* stream);
int getchar(void);
int feof(FILE *stream);
int ferror(FILE *stream);

int remove(const char* filename);
int rename(const char* oldname,const char*newname);
size_t fread(void* ptr, size_t size, size_t max, FILE * stream);
size_t fwrite(void* ptr, size_t size, size_t max, FILE * stream);
long ftell(FILE* stream);
int fseek(FILE *stream, long offset, int whence);
int fsetpos(FILE *stream, const fpos_t *pos);
int fgetpos(FILE * restrict stream, fpos_t * restrict pos);
void rewind(FILE *stream);
void clearerr(FILE* stream);
void perror(char* str);

/* taken from POSIX */
FILE * fmemopen(void * restrict buf, size_t size, const char * restrict mode);
#define fileno(x) ((x)->id)
#if defined(SIMPLEC) && (defined (_M_IX86) || defined (_MANAGED)) 
/* import library bindings to win32 DLLs */
/*	#include "winimp.hil" */
#endif

#endif	
