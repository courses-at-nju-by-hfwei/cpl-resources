#ifndef _setjmp_h
#define _setjmp_h

#include <stddef.h>

#define _setjmp setjmp

typedef size_t jmp_buf[16];

extern int setjmp(jmp_buf env);
extern void longjmp(jmp_buf env,int value);


#endif