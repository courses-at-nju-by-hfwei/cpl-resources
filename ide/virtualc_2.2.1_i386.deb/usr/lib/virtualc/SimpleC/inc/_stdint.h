#ifndef _STDINT_H
#define _STDINT_H
/**************************************************************************
	SimpleC - A Simple C code generator
    (c) 2008 by Dieter R. Pawelczak 

 ****************************************************************************

 Header File stdint.h - as defined in C11 section 7.20
 ToDo: add type long long int

 ****************************************************************************/

typedef signed char    int8_t;
typedef unsigned char  uint8_t;
typedef signed short   int16_t;
typedef unsigned short uint16_t;
typedef signed int     int32_t;
typedef unsigned int   uint32_t;

typedef signed char    int_least8_t;
typedef unsigned char  uint_least8_t;
typedef signed short   int_least16_t;
typedef unsigned short uint_least16_t;
typedef signed int     int_least32_t;
typedef unsigned int   uint_least32_t;

typedef signed char    int_fast8_t;
typedef unsigned char  uint_fast8_t;
typedef signed int     int_fast16_t;
typedef unsigned int   uint_fast16_t;
typedef signed int     int_fast32_t;
typedef unsigned int   uint_fast32_t;

typedef int intptr_t;
typedef int uintptr_t;

typedef long intmax_t; /* ToDo: change to long long */
typedef unsigned long uintmax_t; /* ToDo: change to long long */

#define UINT8_MAX  255
#define UINT16_MAX 65536
#define INT8_MIN   -128
#define INT8_MAX   127
#define INT16_MIN  -32768
#define INT16_MAX  32767
#define UINT32_MAX 4294967295U
#define INT32_MIN  -2147483648
#define INT32_MAX  2147483647
#define INT64_MIN  INT32_MIN
#define INT64_MAX  INT32_MAX
#define UINT64_MAX  UINT32_MAX

#define UINT_LEAST8_MAX  255
#define UINT_LEAST16_MAX 65536
#define INT_LEAST8_MIN   -128
#define INT_LEAST8_MAX   127
#define INT_LEAST16_MIN  -32768
#define INT_LEAST16_MAX  32767
#define UINT_LEAST32_MAX 4294967295U
#define INT_LEAST32_MIN  -2147483648
#define INT_LEAST32_MAX  2147483647

#define UINT_FAST8_MAX  255
#define UINT_FAST16_MAX 4294967295U
#define INT_FAST8_MIN   -128
#define INT_FAST8_MAX   127
#define INT_FAST16_MIN  -2147483648
#define INT_FAST16_MAX  2147483647
#define UINT_FAST32_MAX 4294967295U
#define INT_FAST32_MIN  -2147483648
#define INT_FAST32_MAX  2147483647

#define INTPTR_MIN      -2147483648
#define INTPTR_MAX      2147483647
#define UINTPTR_MAX     4294967295U
/* ToDo: for long long */
#define INTMAX_MIN      -2147483648
#define INTMAX_MAX      2147483647
#define UINTMAX_MAX      4294967295U

#undef PTRDIFF_MIN
#undef PTRDIFF_MAX
#define PTRDIFF_MIN INTPTR_MIN
#define PTRDIFF_MAX INTPTR_MAX

#define WCHAR_MIN 0
#define WCHAR_MAX 255



#define INT8_C(value) value
#define INT16_C(value) value
#define INT32_C(value) value
#define UINT8_C(value) value##U
#define UINT16_C(value) value##U
#define UINT32_C(value) value##U
/* ToDo: long long */
#define INTMAX_C(value) value
#define UINTMAX_C(value) value##U

#endif
