#ifndef _stdlib_h
#define _stdlib_h

/***************************************************************************
	SimpleC - A Simple C compiler, tiny sample C library
    (c) 2008 by Dieter R. Pawelczak 

 ****************************************************************************

 Header File stdlib.h

 ****************************************************************************/

#include <stddef.h>



#define RAND_MAX 32767


#ifdef _M_IX86


__fast char* ltoa(int value,char* str, int base);
__fast char* dtoa(double value,char* str, int base);
__fast char* ultoa(int value,char* str, int base);
__fast long atol(char* str);
__fast double pow10(double in);

__fast void* malloc(size_t size);
__fast void* realloc(void* old, size_t size);
__fast void* calloc(size_t nmemb, size_t size);
__fast void free(void*ptr);
__fast int rand(void);
__fast void srand(unsigned int seed);

#else /*std header */

extern char* utoa(unsigned int value,char* str, int base);
extern long atol(const char* str);
extern int atoi(const char* str);
extern double atof(const char *str);
extern double pow10(double in);
extern void* malloc(size_t size);
extern void* calloc(size_t nmemb,size_t size);
extern void* realloc(void* old, size_t size);
extern void free(void*ptr);
extern int rand(void);
extern void srand(unsigned int seed);
#endif

extern char* itoa(int value,char* str, int base);
extern char* utoa(unsigned int value,char* str, int base);
extern void qsort(void *base,size_t num, size_t width, int (*fpCompare)(const void* a,const void* b));
extern int atoi(const char* str);
extern int abs(int x);
extern long labs(long x);
extern double atof(char *str);

extern double strtod(const char *nptr,char **endptr);
extern float strtof(const char *nptr,char **endptr);
extern long strtol(const char *nptr,char **endptr,int base);
extern unsigned long strtoul(const char *nptr,char **endptr,int base);
#ifdef MOPVM
extern long long strtoll(const char *nptr,char **endptr,int base);
extern unsigned long long strtoull(const char *nptr,char **endptr,int base);
extern long long atoll(const char* str);
#endif

extern _Noreturn void exit(int exitcode);
extern _Noreturn void abort(void);
extern void atexit(void (*fp)(void));
extern _Noreturn void _Exit(int exitcode);
extern int system(const char *command);
extern char *getenv(const char *name);

#define EXIT_SUCCESS 0
#define EXIT_FAILURE 3


#endif
